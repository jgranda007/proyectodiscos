import shutil,sys
from json import decoder
import requests
from requests.auth import HTTPBasicAuth
import csv
from datetime import datetime
import LectorIN
from datetime import datetime
import time

import ast

import json

#Metodo para devolver plataforma y gestor segun codigo postal
def getGestorCP(fileName,num):
  print(fileName)
  print(num)
  if(num != ''):
      file = open(fileName)
      lectura = csv.reader(file,delimiter=',')
      for row in lectura:
        if ((lectura.line_num) > 1):
          campos = row[0].split(';')
          if("PT" in num):
            if("PT" in campos[0]):
              if(int(campos[0][2:len(campos[0])])<int(num[2:len(num)])<int(campos[1][2:len(campos[1])])):
                file.close()
                return (campos[2],campos[3],campos[4])
          else:
            if(int(campos[0])<int(num)<int(campos[1])):
              file.close()
              return (campos[2],campos[3],campos[4])
      file.close()
  else:
    return (None,None,None)

def getGestorCustomerNo(fileName,num):
  file = open(fileName)
  lectura = csv.reader(file,delimiter=',')
  for row in lectura:
    if ((lectura.line_num) > 1):
      campos = row[0].split(';') 
      if(int(num)==int(campos[0])):
         file.close()
         if(len(row)>1):
            file.close()
            return (row[1]+' '+campos[2]).strip()
         else:
            file.close()
            return campos[2].strip()
  file.close()
  return None

def esEntregaRecogida(albaran):
    digitos = str(albaran)[0:2]
    if(digitos=="56"):
        return "Entrega"
    if(digitos=="59"):
        return "Recogida"


# Creación de file de logs
fechaCarga = datetime.now().strftime("%d-%m-%Y_%H-%M")  # Fecha del sistema al finalizar la carga
logsFile = open("Logs/Electrolux_logs_" + fechaCarga + ".txt", "w+")

# Fecha del sistema
sisDate = datetime.now().strftime("%d-%m-%Y_%H-%M")
# Lectura de valores del config file
try:
    # Set the user name and password
    credenciales = open("Config/conf.txt")
    texto = credenciales.read().split("\n")
    user = (texto[0].split("==")[1])
    passw = (texto[1].split("==")[1])
    url = (texto[2].split("==")[1])
    issues_f = (texto[3].split("==")[1])  # Ruta de la carpeta donde estan los ficheros que toca leer
    read_file = (texto[4].split("==")[1])  # Ruta de la carpeta donde mover los ficheros leidos
    """
    logistica_file = (texto[5].split("==")[1])
    cservice_file = (texto[6].split("==")[1])
    rcTraduccion_file = (texto[7].split("==")[1])  # Mapeo de Reason code Electrolux-Dachser
    """
    credenciales.close()
except FileNotFoundError:
    logsFile.write(sisDate + ": ERROR: Archivo de configuracion no encontrado en el directorio IN" + "\n")

# Array con los ficheros dentro del directorio IN
try:
    issues_Files = LectorIN.lector(issues_f)
except (TypeError, FileNotFoundError):
    logsFile.write(sisDate + ": ERROR: La dirección del directorio IN no es correcta" + "\n")

# Verificación de que existan ficheros por leer
if (len(issues_Files[0]) == 0):
    logsFile.write(sisDate + ": ERROR: No se ha encontrado ningún fichero en el direcorio IN para cargar" + "\n")
else:
    # Datos de conexión
    url = url + "/rest/api/2/"
    header = {'Content-Type': 'application/json', 'Accept': 'application/json'}
    """
    #Key de Proyectos
    projectList = []
    # Cosulta Creación de la issue Jira API
    """
    try:
        """
        r = requests.post(url, json=data, headers=header, auth=HTTPBasicAuth(user, passw))
        r = requests.get(jqlUrl, auth=HTTPBasicAuth(user, passw))
        json = (r.json())
        for i in json["issues"]:
            albaranNum = i["fields"]["customfield_11404"]
            albaranList.append(albaranNum)



        asignado = ""
        """
        # Lectura de fichero y carga de tareas de Redmine
        try:
            for archivo in issues_Files[0]:
                with open(issues_f + "/" + archivo) as file:
                    logsFile.write(sisDate + ": Archivo leido: " + str(archivo) + "\n")
                    lectura = csv.reader(file, delimiter=';')
                    for row in lectura:
                        row = [elem.strip() for elem in row] #Para eliminar espacios y tabulaciones delante y detrás
                        # Fecha del sistema
                        sisDate = datetime.now().strftime("%d-%m-%Y_%H-%M")
                        if ((lectura.line_num) > 1):  # Validación de lectura desde la 2da linea y de existencia de Summary
                            print(len(row))
                            #print(row[31])

                            # Consultamos la Key del Proyecto enlazado a la GD para crear la tarea en el proyecto adecuado
                            jqlUrl = url + "search?jql=issuekey%20%3D%20" + row[31]
                            r = requests.get(jqlUrl, auth=HTTPBasicAuth(user, passw))
                            #print(r)
                            result = (r.json())
                            projectKey = ""
                            if(result["total"]==1):
                                print(result["issues"][0]["fields"]["issuelinks"][0]["outwardIssue"]["key"])
                                projectKey = str(result["issues"][0]["fields"]["issuelinks"][0]["outwardIssue"]["key"]).strip().split("-")[0]
                                print(projectKey)
                            else:
                                print("No se han encontrado issues en la búsqueda")

                            # Información de la issue a crear
                            data = """{
                                "fields" : {
                                    "project": {
                                        "key": \"""" + projectKey + """\"
                                    },
                                    "issuetype": {
                                        "name": \""""
                            if(row[29] == 1):
                                data += "Correctivo"
                            elif(row[29] == 2):
                                data += "Evolutivo"
                            else:
                                data += "Soporte"
                            data += """\"
                                    },
                                    "customfield_10200": \"""" + row[0] + """\",
                                    "customfield_10201": \"""" + row[1] + """\",
                                    "customfield_10204": {
                                        "value":\"""" + row[2] + """\"
                                    },
                                    "customfield_10205": {
                                        "value": \"""" + row[3] + """\"
                                    },
                                    "customfield_10206": {
                                        "value" :\""""
                            if(row[4] == 0):
                                data += "No"
                            else:
                                data += "Si"
                            data += """\"
                                    },
                                    "customfield_10401": """
                            if(row[5] == ""):
                                data += "null,"
                            else:
                                data += "\"" + datetime.strptime(row[5], "%d/%m/%Y").strftime("%Y-%m-%d") + "\","
                            data += """
                                    "customfield_10402": """
                            if(row[6] == ""):
                                data += "null,"
                            else:
                                data += row[6] + ","
                            data += """
                                    "customfield_10403": """
                            if(row[7] == ""):
                                data += "null,"
                            else:
                                data += "\"" + datetime.strptime(row[7], "%d/%m/%Y").strftime("%Y-%m-%d") + "\","
                            data += """
                                    "customfield_10404": """
                            if(row[8] == ""):
                                data += "null,"
                            else:
                                data += "\"" + datetime.strptime(row[8], "%d/%m/%Y").strftime("%Y-%m-%d") + "\","
                            data += """
                                    "customfield_10405": """
                            if(row[9] == ""):
                                data += "null,"
                            else:
                                data += "\"" + datetime.strptime(row[9], "%d/%m/%Y").strftime("%Y-%m-%d") + "\","
                            data += """
                                    "customfield_10407": """
                            if(row[10] == ""):
                                data += "null,"
                            else:
                                data += "\"" + datetime.strptime(row[10], "%d/%m/%Y").strftime("%Y-%m-%d") + "\","
                            data += """
                                    "customfield_10408": """
                            if(row[11] == ""):
                                data += "null,"
                            else:
                                data += "\"" + datetime.strptime(row[11], "%d/%m/%Y").strftime("%Y-%m-%d") + "\","
                            data += """
                                    "customfield_10409": {
                                        """
                            if(row[12] == ""):
                                data += "\"id\": \"-1\""
                            elif(row[12] == 0):
                                data += "\"value\": \"No\""
                            else:
                                data += "\"value\": \"Si\""
                            data += """
                                    },
                                    "customfield_10210": {
                                        """
                            if(row[13] == ""):
                                data += "\"id\": \"-1\""
                            elif (row[13] == 0):
                                data += "\"value\": \"No\""
                            else:
                                data += "\"value\": \"Si\""
                            data += """
                                    },
                                    "customfield_10410": \"""" + row[14].replace("\n", " ") + """\",
                                    "customfield_10211": {
                                        """
                            if(row[15] == ""):
                                data += "\"id\": \"-1\""
                            else:
                                data += "\"value\": \"" + row[15] + "\""
                            data += """
                                    },
                                    "customfield_10411": {
                                        """
                            if(row[16] == ""):
                                data += "\"id\": \"-1\""
                            else:
                                data += "\"value\": \"" + row[16] + "\""
                            data += """
                                    },
                                    "customfield_10212": {
                                        "name": "admin"
                                    },
                                    "customfield_10500": {
                                        """
                            if(row[18] == ""):
                                data += "\"id\": \"-1\""
                            else:
                                data += "\"value\": \"" + row[18] + "\""
                            data += """
                                    },
                                    "customfield_10213": {
                                        "value": \""""
                            if(row[19] == 0):
                                data += "No"
                            else:
                                data += "Si"
                            data += """\"
                                    },
                                    "customfield_10214": {
                                        """
                            if(row[20] == ""):
                                data += "\"id\": \"-1\""
                            elif(row[20] == 0):
                                data += "\"value\": \"No\""
                            else:
                                data += "\"value\": \"Si\""
                            data += """
                                    },
                                    "customfield_10413": {
                                        "name": \""""
                            if(row[21] == ""):
                                data += ""
                            else:
                                data += row[21]
                            data += """\"
                                    },
                                    "customfield_10414": {
                                        """
                            if(row[22] == ""):
                                data += "\"id\": \"-1\""
                            else:
                                data += "\"value\": \"" + row[22] + "\""
                            data += """
                                    },
                                    "customfield_10415": {
                                        """
                            if(row[23] == ""):
                                data += "\"id\": \"-1\""
                            else:
                                data += "\"value\": \"" + row[23] + "\""
                            data += """
                                    },
                                    "customfield_10417": \"""" + row[24] + """\",
                                    "customfield_10418": """
                            if (row[25] == ""):
                                data += "null,"
                            else:
                                data += row[25] + ","
                            data += """
                                    "customfield_10419": \"""" + row[26] + """\",
                                    "customfield_10420": """ + row[27] + """,
                                    "customfield_10422": {
                                        "value": \"""" + row[28] + """\"
                                    },
                                    "summary": \"""" + row[32].replace("\n", " ").replace("\"", "'") + """\",
                                    "description": \"""" + row[33].replace("\n", " ").replace("\"", "'").replace("\t", " ").replace("\\", "") + """\",
                                    "duedate": """
                            if (row[34] == ""):
                                data += "null,"
                            else:
                                data += "\"" + datetime.strptime(row[34], "%d/%m/%Y").strftime("%Y-%m-%d") + "\","
                            data += """
                                    "assignee": {"name": "admin"},
                                    "priority": {
                                        "name": \"""" +row[37]+ """\"
                                    },
                                    "reporter": { "name":"reporter1" },
                                    "customfield_10601": {"""
                            if(row[43] == ""):
                                data += "\"id\": \"-1\""
                            else:
                                data += "\"value\": \"" + row[43] + "\""
                            data += """
                                    },
                                    "customfield_10602": {"""
                            if(row[44] == ""):
                                data += "\"id\": \"-1\""
                            else:
                                data += "\"value\": \"" + row[44] + "\""
                            data += """
                                    },
                                    "customfield_10603": {"""
                            if(row[45] == ""):
                                data += "\"id\": \"-1\""
                            else:
                                data += "\"value\": \"" + row[45] + "\""
                            data += """
                                    },
                                    "customfield_10604": {
                                        "value": \""""
                            if(row[46] == 0):
                                data += "No"
                            else:
                                data += "Si"
                            data += """\"
                                    },
                                    "customfield_10605": \"""" + row[47] + """\",
                                    "customfield_10606": {
                                        "value": \""""
                            if(row[48] == 0):
                                data += "No"
                            else:
                                data += "Si"
                            data += """\"
                                    },
                                    "customfield_10607": {
                                        "value": \""""
                            if(row[49] == 0):
                                data += "No"
                            else:
                                data += "Si"
                            data += """\"
                                    },
                                    "customfield_10608": {
                                        "value": \""""
                            if(row[50] == 0):
                                data += "No"
                            else:
                                data += "Si"
                            data += """\"
                                    },
                                    "customfield_10609": {
                                        "value": \""""
                            if(row[51] == 0):
                                data += "No"
                            else:
                                data += "Si"
                            data += """\"
                                    },
                                    "customfield_10610": \"""" + row[52] + """\",
                                    "customfield_10611": { "name":"admin" },
                                    "customfield_10612": {
                                        """
                            if(row[54] == ""):
                                data += "\"id\": \"-1\""
                            else:
                                data += "\"value\": \"" + row[23] + "\""
                            data += """
                                    },
                                    "customfield_10613": \"""" + row[55] + """\",
                                    "customfield_10614": {
                                        "value": \"""" + row[56] + """\"
                                    }
                                }
                            }
                                    """

                            #
                            # if(row[1] == "-1"):
                            #     data += """"id": \"-1\""""
                            # else:
                            #     data += """"value": \"""" + row[1] + """\"},
                            #         "customfield_10201": \"""" +row[2]+ """\",
                            #         "customfield_10203": {"""
                            # if (row[3] == "-1"):
                            #     data += """"id" : \"-1\""""
                            # else:
                            #     data += """"value" : \"""" + row[3] + """\""""
                            # data += """
                            #         },
                            #         "customfield_10204": {
                            #             "value":\"""" +row[4]+ """\"
                            #         },
                            #         "customfield_10205": {
                            #             "value":\"""" +row[5]+ """\"
                            #         },
                            #         "customfield_10206": {"""
                            # if (row[6] == "0"):
                            #     data += """"value": \"No\""""
                            # else:
                            #     data += """"value": \"Si\""""
                            # data += """
                            #         },
                            #         "customfield_10207": {"""
                            # if (row[7] == "0"):
                            #     data += """"value": \"No\""""
                            # data += """
                            #         },
                            #         "customfield_10401": null,
                            #         "customfield_10402": """
                            # if (row[9] == ""):
                            #     data += """0,"""
                            # else:
                            #     data += row[9]+""","""
                            # data += """
                            #         "customfield_10403": """
                            # if (row[10] == ""):
                            #     data += """null,"""
                            # else:
                            #     data += """\"""" + datetime.strptime(row[10], "%d/%m/%Y").strftime("%Y-%m-%d") + """\","""
                            # data += """
                            #         "customfield_10404": """
                            # if (row[11] == ""):
                            #     data += """null,"""
                            # else:
                            #     data += """\"""" + datetime.strptime(row[11], "%d/%m/%Y").strftime("%Y-%m-%d") + """\","""
                            # data += """
                            #         "customfield_10405": """
                            # if (row[12] == ""):
                            #     data += """null,"""
                            # else:
                            #     data += """\"""" + datetime.strptime(row[12], "%d/%m/%Y").strftime("%Y-%m-%d") + """\","""
                            # data += """
                            #         "customfield_10208": {"""
                            # if (row[13] == "0"):
                            #     data += """"value": \"No\""""
                            # else:
                            #     data += """"value": \"Si\""""
                            # data += """
                            #         },
                            #         "customfield_10406": {"""
                            # if (row[14] == "0"):
                            #     data += """"value": \"No\""""
                            # else:
                            #     data += """"value": \"Si\""""
                            # data += """
                            #         },
                            #         "customfield_10407": """
                            # if (row[15] == ""):
                            #     data += """null,"""
                            # else:
                            #     data += """\"""" + datetime.strptime(row[15], "%d/%m/%Y").strftime("%Y-%m-%d") + """\","""
                            # data +="""
                            #         "customfield_10408": """
                            # if (row[16] == ""):
                            #     data += """null,"""
                            # else:
                            #     data += """\"""" + datetime.strptime(row[16], "%d/%m/%Y").strftime("%Y-%m-%d") + """\","""
                            # data += """
                            #         "customfield_10409": """
                            # if (row[17] == ""):
                            #     data += """null,"""
                            # data += """
                            #         "customfield_10209": {"""
                            # if (row[18] == "-1"):
                            #     data += """"id": \"-1\""""
                            # else:
                            #     data += """"value": \"""" + row[18] + """\""""
                            # data += """
                            #         },
                            #         "customfield_10210": {"""
                            # if (row[19] == "-1"):
                            #     data += """"id" : \"-1\""""
                            # elif (row[19] == "0"):
                            #     data += """"value": \"No\""""
                            # else:
                            #     data += """"value": \"Si\""""
                            # data += """
                            #         },
                            #         "customfield_10410": \"""" + row[20].replace("\n", " ") + """\",
                            #         "customfield_10211": {"""
                            # if (row[21] == "-1"):
                            #     data += """"id": \"-1\""""
                            # else:
                            #     data += """"value": \"""" + row[21] + """\""""
                            # data += """
                            #         },
                            #         "customfield_10411": { """
                            # if (row[22] == ""):
                            #     data += """"id": \"-1\""""
                            # data += """
                            #         },
                            #         "customfield_10212": { "name":"admin" },
                            #         "customfield_10500": {"""
                            # if (row[24] == "-1"):
                            #     data += """"id": \"-1\""""
                            # else:
                            #     data += """"value": \"""" + row[24] + """\""""
                            # data += """
                            #         },
                            #         "customfield_10213": {"""
                            # if (row[25] == "0"):
                            #     data += """"value": \"No\""""
                            # else:
                            #     data += """"value": \"Si\""""
                            # data += """
                            #         },
                            #         "customfield_10214": {"""
                            # if (row[26] == "-1"):
                            #     data += """"id" : \"-1\""""
                            # elif (row[26] == "0"):
                            #     data += """"value": \"No\""""
                            # else:
                            #     data += """"value": \"Si\""""
                            # data += """
                            #         },
                            #         "reporter": { "name": "admin" },
                            #         "customfield_10414":{ """
                            # if (row[28] == "-1"):
                            #     data += """"id" : \"-1\""""
                            # else:
                            #     data += """"value": \"""" + row[28] + """\""""
                            # data += """
                            #         },
                            #         "customfield_10415":{ """
                            # if (row[29] == ""):
                            #     data += """"id" : \"-1\""""
                            # else:
                            #     data += """"value": \"""" + row[29] + """\""""
                            # data += """
                            #         },
                            #         "customfield_10416":{ """
                            # if (row[30] == ""):
                            #     data += """"id" : \"-1\""""
                            # elif (row[30] == "0"):
                            #     data += """"value": \"No\""""
                            # else:
                            #     data += """"value": \"Si\""""
                            # data += """
                            #         },
                            #         "customfield_10417": \"""" + row[31] + """\",
                            #         "customfield_10424": \"""" + row[39] + """\",
                            #         "summary": \"""" + row[41].replace("\n", " ").replace("\"", "'") + """\",
                            #         "description": \"""" + row[42].replace("\n", " ").replace("\"", "'").replace("\t", " ") + """\",
                            #         "duedate": """
                            # if (row[43] == ""):
                            #     data += """null,"""
                            # else:
                            #     data += """\"""" + datetime.strptime(row[43], "%d/%m/%Y").strftime("%Y-%m-%d") + """\","""
                            # data += """
                            #         "assignee": { "name": "admin" },
                            #         "priority": {
                            #             "name": \"""" +row[48]+ """\"
                            #         },
                            #         "reporter": { "name":"reporter1" }
                            #     }
                            # }"""
                            print(data)
                            dataDict = json.loads(data)
                            print(str(dataDict))
                            """
                            # Creación de la issue
                            r = requests.post(url + "issue", json=dataDict, headers=header, auth=HTTPBasicAuth(user, passw))
                            result = (r.json())
                            print("--------------------------------------------------------------------------------")
                            print("--------------------------------------------------------------------------------")
                            print(sisDate + ": Issue creada: " + str(r.content) + str(row[0]) + "\n")
                            print("--------------------------------------------------------------------------------")
                            print("--------------------------------------------------------------------------------")
                            logsFile.write(sisDate + ": Issue creada: " + str(r.content) + str(row[0]) + "\n")

                            # Transición de la issue

                            print(result["key"])

                            time.sleep(1)
                            """

        except FileNotFoundError:
            logsFile.write(sisDate + ": Error: Archivo de carga de issues no encontrado" + "\n")
    except requests.exceptions.ConnectionError:
        logsFile.write(sisDate + "ERROR: En la URL de consulta del numero de Albaran" + "\n")
    except KeyError:
        logsFile.write(
            sisDate + "ERROR: La key que se intenta referenciar no existe dentro del JSON de respuesta a la JQL hecha." + "\n")
    except decoder.JSONDecodeError:
        logsFile.write(sisDate + ": ERROR: En las credenciales del usuario configurado" + "\n")
logsFile.close()
