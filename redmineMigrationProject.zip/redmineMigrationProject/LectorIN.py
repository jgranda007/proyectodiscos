import os
import csv

#Lectura del fichero en In
def lector(direccion):
    f = []
    with os.scandir(direccion) as ficheros:
        f.append([fichero.name for fichero in ficheros if fichero.is_file() and fichero.name.endswith('.csv')])
    return f

'''
@param Reason Code de Dascher
@param Ruta del fichero con la tabla de traduccion
@return Lista con: Reason Code traducido, Mensaje del proceso
'''
def traductor(dascher_rc, tablaEquiv):
    respuesta = ["","","",""]  # Reason Code, Mensaje
    try:
        with open(tablaEquiv) as file:
            lectura = csv.reader(file, delimiter=';')
            for fila in lectura:
                if (lectura.line_num) > 1:  # Validación de lectura desde la 2da linea
                    if fila[0].strip() == dascher_rc.strip():
                        respuesta[0] = str(fila[3].strip()) #Traducción del Reason Code
                        respuesta[1] = str(fila[1].strip()) #Descripcion Reason Code
                        respuesta[2] = str(fila[2].strip()) #Departamento Electrolux
                        respuesta[3] = " Se ha traducido el Dascher reason code: " + dascher_rc + " por el Reason Code: " + str(
                            respuesta[0])
                        print("Traducción de: " + str(dascher_rc) + " es --> " + respuesta[0])
            if respuesta[0] == "":
                respuesta[3] = " Error: No se ha podido traducir el Dascher reason code: " + dascher_rc + " porque no se encontró una equivalencia en la tabla de traducción"
    except:
        respuesta[3] = " ERROR: No se ha podido leer el archivo de traducción del Dascher reason code: " + dascher_rc
    return respuesta
