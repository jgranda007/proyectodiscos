import requests
from requests.auth import HTTPBasicAuth

url = "http://localhost:8080/rest/api/2/issue"
header = {'Content-Type': 'application/json','Accept': 'application/json'}
#Set the user name and password values
user = 'admin'
passw = 'itera2020'

#Información de la issue creada
data = {
    "fields": {
        "project": {
            "key": "TEST" #Llave del Proyecto donde se va a crear
        },
        "summary": "Python con datos",
        "description": "Issue creado desde Python",
        #"customfield_11404":"123", #Numero de Albaran,
        #"customfield_11401":"456", #Numero de PNC
        #"customfield_11406":"0000", #Reason code
        #"customfield_11600":"2456", #Codigo Postal
        "issuetype": {
            "name": "Historia"
        }
    }
}

#Creación de la issue Jira API
r = requests.post(url, json=data, headers=header, auth=HTTPBasicAuth(user, passw))
print ("HERE's the JSON RESPONSE\n\n ", r.status_code, r.headers)
print ("Respuesta de la solicitud: \n\n", r.content)

"""
            #dict((key,value) for(key,value) in "customfield_10202".items() if(value == "-1"))
            "id": row[1],
        },
        "customfield_10201": row[2],
        "customfield_10203": {
            "id": row[3],
        },
        "customfield_10204": {
            "id": row[4]
        },

        "summary": row[43],

        "reporter": { "name":"reporter1" },
        "description": row[44],

    }# Tipo de incidencia
}
"""

# """


"""
    if ((str(row[0]) not in albaranList)):
        # Traducción del Reason code Dascher al de Electrolux
        reasonC = []
        try:
            reasonC = LectorIN.traductor(str(row[2]), rcTraduccion_file)
            logsFile.write(sisDate + reasonC[3] + "\n")
            print("Reason Code TRADUCIDO: " + reasonC[0])

        except FileNotFoundError:
            logsFile.write(
                sisDate + ": ERROR: No se pudo hacer la traducción del Reason Code de la issue con número de Albaran: " + str(row[0]) + " porque el archivo de traducción no se encontró" + "\n")
        #else:
         #   logsFile.write(
          #      sisDate + ": ERROR: No se pudo hacer la traducción del Reason Code de la issue con número de Albaran: " + str(row[0]) + "\n")
        if reasonC[0] != "":
            fecha_obj = datetime.strptime(str(row[5]),'%d/%m/%Y')
            fechaFinal = fecha_obj.strftime("%Y-%m-%d")
            print(fechaFinal)
            # Información de la issue para actualizar
            data = {"fields": {  # Llave del Proyecto donde se va a crear
                           "description": str(row[3]),
                           #"customfield_11404": str(row[0]),  # Numero de Albaran,
                           "customfield_11401": str(row[2]),  # Numero de PNC
                           "customfield_11406": str(reasonC[0]),  # Reason code
                           "customfield_11901": str(reasonC[1]), #descripcion reason code
                            "customfield_11902": {"value":str(reasonC[2])}, #departamento
                           #"customfield_11700": str(plataforma), #str(row[4]),  # Plataforma
                           #"customfield_11903": {"value":str(plataforma)}, #PLataforma (lista)
                           #"assignee": {"name": str(asignado)},
                           "customfield_11702": str(row[4]),  # Ship to
                           #"customfield_11701": str(row[4]),  # Sold to
                           "customfield_11600": str(row[1]),  # Codigo Postal
                           #"customfield_11806": str(emailPlataforma), #email por plataform
                           "customfield_11900": str(fechaFinal), #fecha de incidencia
                           "customfield_11807": {"value":str(row[7])}, #Proveedor
                           "customfield_12000": {"value":esEntregaRecogida(row[0])} #Tipo de incidencia
                        }
                }
            print("PLataforma-cliente:"+reasonC[0])
            # Seteo del asignado
            if (int(reasonC[0]) < 5):  # Incidencias de logistica
                try:
                    result = getGestorCP(logistica_file,str(row[1]))
                    asignado=""#result[1]
                    plataforma=result[0]
                    emailPlataforma=result[2]
                    print(asignado)
                    print(plataforma)
                    #with open(logistica_file) as file:
                    #    lector = csv.reader(file, delimiter=',')
                    #    for fila in lector:
                    #        if ((lector.line_num) > 1):  # Validación de lectura desde la 2da linea
                    #            if (str(fila[0]) != '' and str(fila[1]) == '' or (
                    #                    str(fila[0]) == '' and str(fila[1]) != '')):

                    #                if (str(fila[0]) == str(row[5]) and str(
                    #                        fila[0]) != ''):  # Fila 0: Plataforma
                    #                    print("Asignado por plataforma")
                    #                    asignado = str(fila[2])
                    #                    break
                    #                elif (str(fila[1]) == str(row[4]) and str(
                    #                        fila[1]) != ''):  # Fila 1 : Codigo Postal
                    #                   print("Asignado por Codigo postal")
                    #                    asignado = str(fila[2])
                    #                    break
                    #                print("Fila 1: " + str(fila[1]))
                    #                print("Row 1: " + str(row[4]))
                    #                print("---------------------------------------")
                    #            else:
                    #                logsFile.write(sisDate + ": ERROR: El Reason code " + str(reasonC[0]) + " no es valido porque contiene Plataforma y Codigo postal" + "\n")
                    if asignado == None:
                        logsFile.write(
                            sisDate + ": Error: Issue con numero de Albaran: " + str(row[0]) +
                            " no se ha podido crear con un asignado porque no tiene asociada ni una plataforma ni un codigo postal" + "\n")
                        asignado=''

                except FileNotFoundError:
                    logsFile.write(sisDate + ": Error: Issue con numero de Albaran: " + str(row[0]) + " no se ha podido crear con un asignado porque el archivo Logistica Asignados no se ha encontrado" + "\n")

            elif (int(reasonC[0]) > 4 and int(reasonC[0]) < 9):  # Incidencias Customer Service
                try:
                    emailPlataforma=""
                    plataforma=""
                    soldToNumber=str(row[4])
                    print(str(row[4]))
                    if('-' in soldToNumber):
                        soldToNumber=str(row[4]).split('-')[0]

                    asignado = getGestorCustomerNo(cservice_file,soldToNumber)
                    #with open(cservice_file) as file:
                    #    lector = csv.reader(file, delimiter=',')
                    #    for fila in lector:
                    #        if ((lector.line_num) > 1):  # Validación de lectura desde la 2da linea
                    #            if ((str(fila[0]) != '' and str(fila[1]) == '') or (
                    #                    str(fila[0]) == '' and str(fila[1]) != '')):
                    #                if (str(fila[0]) == str(row[0]) and str(fila[0]) != ''):
                    #                    print("Asignado por Sold To")
                    #                    asignado = str(fila[2])
                    #                    break
                    #                elif (str(fila[1]) == str(row[1]) and str(fila[1]) != ''):
                    #                    print("Asignado por Ship to")
                    #                    asignado = str(fila[2])
                    #                    break

                                #else:
                                #    logsFile.write(sisDate + ": ERROR: El Reason code " + str(reasonC[0]) + " no es valido porque contiene Solve to y Shift to" + "\n")
                    if asignado == "":
                        logsFile.write(
                            sisDate + ": Error: Issue con numero de Albaran: " + str(row[0]) +
                            " no se ha podido crear con un asignado porque no tiene asociada ni un Sold To ni un Ship To" + "\n")
                except FileNotFoundError:
                    logsFile.write(sisDate + ": Error: Issue con numero de Albaran: " + str(row[0]) + " no se ha podido crear con un asignado porque el archivo Customer Service Asignados no se ha encontrado" + "\n")

        else:
            logsFile.write(
                sisDate + ": ERROR: El Reason code " + str(reasonC[0]) + " no es valido" + "\n")
        #Tratar la fecha de incidencia
        fecha_obj = datetime.strptime(str(row[5]),'%d/%m/%Y')
        fechaFinal = fecha_obj.strftime("%Y-%m-%d")
        print(fechaFinal)
        # Información de la issue creada                             
        data = {"fields": {"project": {"key": "SDEVOLU"},  # Llave del Proyecto donde se va a crear
                           "summary": "Albaran: " + str(row[0]),
                           "description": str(row[3]),
                           "customfield_11404": str(row[0]),  # Numero de Albaran
                           "customfield_12001": str(row[0]),  # DNP,
                           "customfield_11401": str(row[2]),  # Numero de PNC
                           "customfield_11406": str(reasonC[0]),  # Reason code
                           "customfield_11901": str(reasonC[1]), #descripcion reason code
                           #"customfield_11902": {"value":str(reasonC[2])}, #departamento
                           #"customfield_11700": str(plataforma), #str(row[4]),  # Plataforma
                           #"customfield_11903": {"value":str(plataforma)}, #PLataforma (lista)
                           "assignee": {"name": str(asignado)},
                           "customfield_11702": str(row[4]),  # Ship to
                           #"customfield_11701": str(row[4]),  # Sold to
                           "customfield_11600": str(row[1]),  # Codigo Postal
                           "customfield_11806": str(emailPlataforma), #email por plataform
                           "customfield_11900": str(fechaFinal), #fecha de incidencia
                           "customfield_12002": str(row[6]), #Nombre del cliente
                           #"customfield_11807": {"value":str(row[7])}, #Proveedor
                           "customfield_12000": {"value":esEntregaRecogida(row[0])}, #Tipo de incidencia
                           "issuetype": {"name": "Incidencia de transporte"}}
                }                               
        if(str(row[7])!=''):
            data['fields'].update({"customfield_11807": {"value":str(row[7])}})
        if(str(plataforma)!=''):
            data['fields'].update({"customfield_11903": {"value":str(plataforma)}})
        if(str(reasonC[2])!=''):
            data['fields'].update({"customfield_11902": {"value":str(reasonC[2])}})

        print(data)
        # Creación de la issue Jira API
        r = requests.post(url + "issue", json=data, headers=header, auth=HTTPBasicAuth(user, passw))
        logsFile.write(sisDate +
                       ": Issue creada: " + str(r.content) +
                       "Asignado a: " + asignado +
                       ", Numero de Albaran: " + str(row[0]) + "\n")
    else:  # Validación de los numeros de Albaran asociadas a issues que ya existen y estan activas
        nAlbaran = str(row[0])  # numero de albaran

        # Consulta de la issue abierta con Numero de albaran
        query = "search?jql=%22Numero%20de%20Albaran%22%20~%20%22" + nAlbaran + "%22%20and%20resolution%20%3D%20Unresolved&fields=id,key,customfield_11404"
        jqlUrl = url + query
        # Get de la issue que se va a actualizar
        re = requests.get(jqlUrl, auth=HTTPBasicAuth(user, passw))
        jsonResp = (re.json())
        if jsonResp["total"] == 1:
            issueKey = ""
            # Get Issue Key de la issue con el Numero de Albaran encontrado
            for i in jsonResp["issues"]:
                issueKey = i["key"]
                print("ISSUE KEY ----> " + issueKey)

            # Traducción del Reason code Dascher al de Electrolux
            reasonC = ["", ""]
            try:
                reasonC = LectorIN.traductor(str(row[2]), rcTraduccion_file)
                logsFile.write(sisDate + reasonC[3] + "\n")
                print("Reason Code TRADUCIDO: " + reasonC[0])

            except FileNotFoundError:
                logsFile.write(
                    sisDate + ": ERROR: No se pudo hacer la traducción del Reason Code de la issue con número de Albaran: " + nAlbaran + " porque el archivo de traducción no se encontró" + "\n")
           # else:
                #logsFile.write(
                   # sisDate + ": ERROR: No se pudo hacer la traducción del Reason Code de la issue con número de Albaran: " + nAlbaran + "\n")

            if reasonC[0] != "":
                fecha_obj = datetime.strptime(str(row[5]),'%d/%m/%Y')
                fechaFinal = fecha_obj.strftime("%Y-%m-%d")

                # Información de la issue para actualizar
                data = {"fields": {  # Llave del Proyecto donde se va a crear
                           "description": str(row[3]),
                           #"customfield_11404": str(row[0]),  # Numero de Albaran,
                           "customfield_11401": str(row[2]),  # Numero de PNC
                           "customfield_11406": str(reasonC[0]),  # Reason code
                           "customfield_11901": str(reasonC[1]), #descripcion reason code
                            "customfield_11902": {"value":str(reasonC[2])}, #departamento
                           #"customfield_11700": str(plataforma), #str(row[4]),  # Plataforma
                           #"customfield_11903": {"value":str(plataforma)}, #PLataforma (lista)
                           #"assignee": {"name": str(asignado)},
                           "customfield_11702": str(row[4]),  # Ship to
                           #"customfield_11701": str(row[4]),  # Sold to
                           #"customfield_11600": str(row[1]),  # Codigo Postal
                           #"customfield_11806": str(emailPlataforma), #email por plataform
                           "customfield_11900": str(fechaFinal), #fecha de incidencia
                           "customfield_11807": {"value":str(row[7])}
                        }
                }
                print("JSON editar")
                print(data)
                # Edición de la issue Jira API
                r = requests.put(url + "issue/" + issueKey, json=data, headers=header,
                                 auth=HTTPBasicAuth(user, passw))
                if(r.status_code == 204 or r.status_code == 200):
                    comentario = {
                        "body": "Issue actualizada desde el fichero de carga. Reason code actualizado: " + str(
                            row[2]) + " por el nuevo Reason Code: " + reasonC[0]}

                    postComment = requests.post(url + "issue/" + issueKey + "/comment", json=comentario,
                                                headers=header, auth=HTTPBasicAuth(user, passw))

                    logsFile.write(sisDate +
                                   ": Issue actualizada con Numero de Albaran: " + str(row[0]) +
                                   ", Reason code: " + reasonC[0] +
                                   ", Solicitud de nuevo comentario: " + str(postComment.content) +
                                   "\n")
                else:
                    logsFile.write(sisDate + ": Error: Error al editar: "+str(r.text)+"\n")
            else:
                logsFile.write(sisDate + ": Error: Reason Code vacio: \n")

        else:
            logsFile.write(
                sisDate + ": Error: Hay más de una issue abierta con el número de Albaran: " + nAlbaran + "\n")
    asignado = ""
"""
"""
# Move from In to Out folder
fechaCarga = datetime.now().strftime("%d-%m-%Y_%H-%M")  # Fecha del sistema al finalizar la carga
try:
    shutil.move(issues_f + "/" + archivo, read_file + "/Atributos_" + fechaCarga + "_" + str(archivo))
except FileNotFoundError:
    logsFile.write(
        sisDate + ": Error: Archivo de carga de issues no encontrado y no se pudo mover al directorio Out" + "\n")
"""



"""
                            for i in json["issues"]:
                                albaranNum = i["fields"]["customfield_11404"]
                                albaranList.append(albaranNum)
                            """
