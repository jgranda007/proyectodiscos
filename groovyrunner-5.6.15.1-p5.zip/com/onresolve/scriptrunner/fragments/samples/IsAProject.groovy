package com.onresolve.scriptrunner.fragments.samples

jiraHelper.project?.key == "JRA"