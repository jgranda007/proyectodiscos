package com.onresolve.scriptrunner.fragments.samples

issues*.projectObject.unique().size() == 1