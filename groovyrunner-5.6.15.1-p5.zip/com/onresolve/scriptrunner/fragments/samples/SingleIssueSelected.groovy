package com.onresolve.scriptrunner.fragments.samples

issues.size() == 1