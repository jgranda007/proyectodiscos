package com.onresolve.scriptrunner.fragments.samples

issues.every { !it.labels*.label.contains('red') }