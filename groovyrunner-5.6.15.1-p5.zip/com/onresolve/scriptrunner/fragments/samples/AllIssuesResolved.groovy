package com.onresolve.scriptrunner.fragments.samples

issues.every { it.resolution }