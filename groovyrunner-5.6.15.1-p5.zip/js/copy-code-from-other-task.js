require("wr-dependency!com.atlassian.auiplugin:dialog2");

(function ($) {
    var paramsShown = "/start/com.onresolve.scriptrunner.canned.bamboo.tasks.scriptable.ScriptableTask";

    $(document).off(paramsShown).on(paramsShown, function () {
        var $copyTaskLink = $("#copy-from-other-task"),
            selectTaskDialogSelector = "#select-task-dialog",
            dialog;

        $copyTaskLink.off("click").on("click", function (e) {
            // open dialog
            dialog = AJS.dialog2(selectTaskDialogSelector);
            dialog.show();
        });

        AJS.$("#dialog-close-button").off("click").click(function(e) {
            e.preventDefault();
            dialog.hide();
        });

        AJS.$("#dialog-submit-button").off("click").click(function(e) {
            var taskIdx = $(selectTaskDialogSelector).find("#select-task").val(),
                planKey = $copyTaskLink.closest("form").find(":input[name=planKey]").val();

            $.ajax({
                type: "GET",
                url: AJS.contextPath() + "/rest/scriptrunner-bamboo/latest/tasks/" + planKey + "/" + taskIdx + "/code"
            }).fail(function (XMLHttpRequest, textStatus, errorThrown) {
                AJS.messages.error("#error-context", {
                    title: 'Could not retrieve code.',
                    body: '<p>Failure to generate code, perhaps the plan, job or task has been deleted</p>'
                });

            }).done(function (data) {
                // copy response to codemirror
                var $input = $copyTaskLink.closest("div.field-group").find(":input.CodeMirror");
                var cm = $input.data("CodeMirrorInstance");
                if (typeof (cm) !== "undefined") {
                    cm.setValue(data);
                }
                else {
                    alert("Failed to write code to editor, code is:\n" + text)
                }

                e.preventDefault();
                dialog.hide();
            });
        });
    });
})(AJS.$);
