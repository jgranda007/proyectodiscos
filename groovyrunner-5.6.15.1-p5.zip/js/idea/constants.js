if (typeof window.ScriptRunner == 'undefined') {
    window.ScriptRunner = {};
}
if (typeof window.ScriptRunner.Idea == 'undefined') {
    window.ScriptRunner.Idea = {};
}

if (typeof window.ScriptRunner.Events == 'undefined') {
    window.ScriptRunner.Events = {SCRIPT_EXECUTED_SUCCESS : "scriptexecutedsuccess"};
}

export const EDITOR_INIT = "sr-editor-init";
