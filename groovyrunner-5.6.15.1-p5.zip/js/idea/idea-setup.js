import {defaultAjaxSettings, initialiseToken} from "./idea-common.js";
import {options} from "../common-options";

import '../icon-wait.css'

let baseUrl = options.url + "/api/scriptrunner-idea/exec";

$.fn.serializeObject = function()
{
    var o = {};
    var a = this.serializeArray();
    $.each(a, function() {
        if (o[this.name] !== undefined) {
            if (!o[this.name].push) {
                o[this.name] = [o[this.name]];
            }
            o[this.name].push(this.value || '');
        } else {
            o[this.name] = this.value || '';
        }
    });
    return o;
};

function validateProject() {
    return $.ajax($.extend({}, defaultAjaxSettings, {
        url: baseUrl + "?class=com.adaptavist.idea.actions.ValidateOrCreateMavenProject",
        data: JSON.stringify($.extend({}, options, {
            "async": true,
            title: "Validating or creating project..."
        }, $("#idea-setup-form").serializeObject()))
    }));
}

function updateIdea(e) {
    return $.ajax({
        url: AJS.params.baseURL + "/rest/scriptrunner/latest/idea/server/update",
        type: "POST",
        dataType: "json",
        data: $("#idea-setup-form").serializeArray()
    });
}

function stopIdea() {
    return $.ajax({
        url: AJS.params.baseURL + "/rest/scriptrunner/latest/idea/server/stop",
        type: "POST",
        contentType: "application/json"
    });
}

function isProjectReady() {
    return $.ajax($.extend({}, defaultAjaxSettings, {
        url: baseUrl + "?class=com.adaptavist.idea.scripts.ProjectHealthCheck"
    }));
}

function isIdeaReady() {
    return $.ajax($.extend({}, defaultAjaxSettings, {
        type: "GET",
        url: AJS.params.baseURL + "/rest/scriptrunner/latest/idea/server/status"
    }));
}

function reEnableToggle($enableIdeaToggle, state) {
    $enableIdeaToggle.find("button.mode-disabled").attr("aria-pressed", !state);
    $enableIdeaToggle.find("button.mode-enabled").attr("aria-pressed", state);
    $enableIdeaToggle.find(".aui-icon-wait").remove();
    $enableIdeaToggle.find(".aui-button").removeAttr("disabled");
}

function setTaskIndicator(task) {
    const $progressIndicator = $(com.adaptavist.idea.taskIndicator({task: task}));
    const $auiProgressIndicator = $progressIndicator.find(".aui-progress-indicator");
    // AJS.progressBars.update($auiProgressIndicator, task["fraction"]);
    AJS.progressBars.setIndeterminate($auiProgressIndicator);
    $("div#task-indicator-container").empty().append($progressIndicator);
}
function timeoutProjectReady(totalTime) {
    const timeOut = 500;
    setTimeout(function () {
        isProjectReady().done(function (data) {
            if (!data.ready) {

                data.tasks.forEach(function (task) {
                    setTaskIndicator(task);
                });

                if (totalTime > 300000) { // todo some long number
                    console.warn("Failed to load project in the time allotted");
                }
                timeoutProjectReady(totalTime + timeOut);
            }
            else {
                $("#idea-progress-indicator").remove();
                const $enableIdeaToggle = $("#enable-idea");
                reEnableToggle($enableIdeaToggle, true);

                window.require(['aui/flag'], function(flag) {
                    flag({
                        type: 'success',
                        title: 'Code editor',
                        persistent: false,
                        body: 'The editing environment is ready to go!'
                    });
                });
            }
        }).fail(function () {
            timeoutProjectReady(totalTime + timeOut);
        });
    }, timeOut)
}

function timeoutIdeaStarted(totalTime) {
    const timeOut = 200;
    setTimeout(function () {
        isIdeaReady().done(function (data) {
            console.log("idea ready");
            options.url = data.url;
            baseUrl = data.url + "/api/scriptrunner-idea/exec"; // needs some markg love around here todo
            // now validate project
            validateProject().done(function () {
                if (data && data.ready) {
                    $("#idea-progress-indicator").remove();
                }
                else {
                    timeoutProjectReady(0);
                }
            }).fail(function () {
                timeoutProjectReady(0);
            });

        }).fail(function (xhr, status, error) {
            try {
                const data = $.parseJSON(xhr.responseText);
                const task = {
                    taskInfo: "Downloading support files",
                    text: data.message,
                    text2: ""
                };

                setTaskIndicator(task);
            }
            catch (e) {
                console.error("Not ready", e)
            }

            timeoutIdeaStarted(0);
        });
    }, timeOut)
}

function spinner() {
    return $('<span style="margin-left: 10px" class="aui-icon aui-icon-wait">Loading...</span>');
}

function enableIdea(e) {
    updateIdeaStatus(true, e)
}

function updateIdeaStatus(enable, e) {
    e.preventDefault();

    const $button = $(e.target);
    if ($button.attr("aria-pressed") == "true") {
        return
    }

    var enable = $("#enable-idea").find("button[aria-pressed=true]").hasClass("mode-enabled");

    $("#enable-idea .aui-button").attr("disabled", "disabled");
    $("#enable-idea").append(spinner());

    if (enable) {
        updateIdea(e).done(function (data) {
            timeoutIdeaStarted(0);
        }).fail(function (a, b, c) {
            console.error('Server reported error');
        });
    }
    else {
        stopIdea().done(function (data) {
            console.log("disabled successfully");
            var $enableIdeaToggle = $("#enable-idea");
            reEnableToggle($enableIdeaToggle, false);
        }).always(function () {
            var $enableIdeaToggle = $("#enable-idea");
            reEnableToggle($enableIdeaToggle);

        });
    }
}

function onDocumentReady() {

    initialiseToken(false).done(function () {

        $("#enable-idea").find("button").on("click", function (e) {
            e.preventDefault();
            $(this).closest("form").find("input[name=idea-enabled]").val($(this).hasClass("mode-enabled"));
            $(this).parent().find("button").attr("aria-pressed", false);
            $(this).attr("aria-pressed", true);
        });

        $("input[name=radsLocalRemote]").on('change', function (e) {
            console.log(this.id);

            $("#fgPort, #fgTempFiles, #fgServerAddress").toggle()
        });

        $("#idea-setup-form").on("submit", function (e) {
            e.preventDefault();
            console.log("form submit");

            enableIdea(e);
            return;

            $.ajax({
                type: "POST",
                url: AJS.params.baseURL + "/rest/scriptrunner/latest/idea/server/update",
                data: $(this).serialize(),
                success: function (data) {
                    console.log(data); // show response from the php script.
                }
            });
        });

        // $("#enable-idea").find("button.mode-enabled").off('click').on('click', function (e) {
        //     enableIdea(e);
        // });
        //
        // $("#enable-idea").find("button.mode-disabled").off('click').on('click', function (e) {
        //     disableIdea(e);
        // });
    });
}

$(onDocumentReady);

if(module.hot) {
    console.log("hmr available");

    module.hot.accept(function () {
        console.log("accepted");
    });

    module.hot.dispose(function() {
        console.log("dispose");
        // revoke the side effect
        // $("#btn").off("click");
    });
}
//

