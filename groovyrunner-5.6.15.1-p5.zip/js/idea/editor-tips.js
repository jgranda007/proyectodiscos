import {EDITOR_INIT} from "./constants";
import {getContainer, getEditor, getId, setData} from "./editor-utils";
import {executeClientActions, action} from "./action-utils";

$(document).on(EDITOR_INIT, initTips);

$(function () {
    bindDelegatedTipHandlers()
});

// Popup tips - anchor to the cursor
//
// Tips are not focused by default, unless something inserted has the class 'focus'.
// When a focused tip is closed the last active editor will regain the focus.
// todo: move into own module

const keyCode = {
    UP: 38,
    DOWN: 40
};

let focusedEditor;

function getTipId(editorSpec) {
    return "editor-tip-" + getId(editorSpec).replace("\.", "-").replace("\:", "-");
}

export function getTip(editorSpec) {
    return $(document.getElementById(getTipId(editorSpec)));
}

function getEditorIdFromInsideTip(element) {
    return $(element).closest(".aui-inline-dialog-contents").data("editorSpec");
}

function initTips(event) {
    const tipId = getTipId(event.target);

    if (!document.getElementById(tipId)) {
        getContainer(event.target).find(".ace_cursor").attr("aria-controls", tipId);
        $(com.adaptavist.idea.tip({id: tipId})).appendTo(document.body);
    }
}

// register general tip event handlers only once
function bindDelegatedTipHandlers() {
    $(document)
        // code examples
        .on("click", "a.code-example", function (event) {
            event.preventDefault();
            const editor = getEditor($(event.target).closest(".field-group").find(".ace-editor"));
            const code = $(this).attr("data-code");
            editor.setValue(code);
        })
        .on("keydown", ".editor-choice", function (event) {
            switch (event.keyCode) {
                case keyCode.DOWN:
                    event.preventDefault();
                    $(this).find("li:has(a:focus)").next().find("a").focus();
                    break;
                case keyCode.UP:
                    event.preventDefault();
                    $(this).find("li:has(a:focus)").prev().find("a").focus();
                    break;
            }
        })
        .on("click", ".editor-choice a", function (event) {
            const $a = $(this);
            const actionName = $a.closest("[data-action]").attr("data-action");

            if (actionName) {
                event.preventDefault();
                $a.closest(".editor-tip").removeAttr("open"); // broken

                executeClientActions([
                    action(getEditorIdFromInsideTip($a), actionName,
                        {
                            text: $a.text(),
                            href: $a.attr("href")
                        })
                ]);
                $a.closest(".aui-inline-dialog").hide();

                if (focusedEditor) {
                    focusedEditor.focus();
                }
            }
        })
        .on("aui-hide", function () {
            if (focusedEditor) {
                focusedEditor.focus();
            }
        });
}

export function showTip(editorSpec, content) {
    // Perform in next event loop in case cursor was moved

    const container = getContainer(editorSpec);
    focusedEditor = getEditor(editorSpec);

    setTimeout(function () {
        //noinspection JSUnusedGlobalSymbols
        const dialog = AJS.InlineDialog(container.find(".ace_cursor"), getTipId(editorSpec), function (contents, trigger, showPopup) {
            $(content).find("a:first").focus();
            contents.data("editorSpec", editorSpec).css("padding", "5px").css("max-width", "1000px").css("width", "").html(content);
            showPopup();
            return false;
        }, {
            offsetX: -15,
            hideCallback: function () {
                console.log("removing", $("#" + getTipId(editorSpec)));
                $("#inline-dialog-" + getTipId(editorSpec)).remove();
                if (focusedEditor) {
                    focusedEditor.focus();
                }
            }
        });
        dialog.show();
        dialog.find(".contents li a:first").focus();

        setData(editorSpec, "inline-dialog", dialog);
    }, 0);

    setTimeout(function () {
        $(".editor-choice a.focus").focus();
    }, 100);
}
