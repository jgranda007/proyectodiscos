import {defaultAjaxSettings} from "./idea-common.js";
import * as idea from "./editor-utils.js";
import {getEditorStatus} from "./editor-utils";
import {options} from "../common-options";

import '../icon-wait.css'

const $ = AJS.$;

const appBaseUrl = AJS.params.baseURL;
let actionsUrl = options.url + "/api/scriptrunner-idea/actions";

export var channelId;

// Execute a list of client actions
export function executeClientActions(clientActions) {
    clientActions.forEach(function (action) {
        const name = action.name || action.action; // todo: switch server-side construction of client-actions to use 'name' property only
        if (name) {
            console.log("Client action:", name, action);

            if (action.id) {
                const $editorStatus = getEditorStatus(action.id);
                editorStopSpin($editorStatus);

                // Target a specific element if an id is present, otherwise the document
                const target = action.id ? document.getElementById(action.id) : document;

                $(target).trigger(name, [action]);
            }
            else {
                $(document).trigger(name, [action]);
            }
        }
    });
}

function parseJSON(response) {
    return response.json();
}

function executionServerActionsViaHttp(channelId, serverActions) {
    actionsUrl = options.url + "/api/scriptrunner-idea/actions";

    if (Object.prototype.toString.call(serverActions) !== '[object Array]') {
        serverActions = [serverActions];
    }

    if (serverActions.length) {
        console.log("Server actions: ", serverActions);
        serverActions.forEach(function (action) {
            console.log("Server action:", action.name, action);
            action.channelId = channelId;
            action.baseUrl = options.canonicalBaseUrl;
            action.application = PLATFORM_NAME;
        });

        return fetch(actionsUrl, {
            method : "POST",
            body   : JSON.stringify(serverActions),
            headers: {
                "Content-Type": "application/json",
            }
        }).then(parseJSON)
            .then((clientActions) => {
                if (Array.isArray(clientActions)) {
                    executeClientActions(clientActions);
                } else {
                    console.error("Expected an array of actions, got:", clientActions);
                }
            }).catch((error) => {
                window.require(['aui/flag'], function (flag) {
                    flag({
                        type : 'error',
                        title: 'IDEA Editor',
                        close: 'manual',
                        body : `Editor reported a failure... please check IDEA logs. See <a href="https://scriptrunner.adaptavist.com/latest/jira/intellij-integration.html#_troubleshooting" target="_blank">our documentation</a> for how to find them.`
                    });
                });
            });
    }
}

// stops spinners after clicking the link - did not find a good way to just stop the one click so all are stopped
export function stopAllSpinners() {
    return // removing the child spinner breaks React. This was used mainly for the Ace editor anyway.
    const $openInIdeaLinks = $("a.open-in-idea");
    $openInIdeaLinks.find("span.aui-icon-wait").remove();
    $openInIdeaLinks.children().show();
}

export function executeServerActions(serverActions) {
    console.log("Server actions", serverActions);

    if (channelId) {
        executionServerActionsViaHttp(channelId, serverActions);
        stopAllSpinners();
    }
    else {
        // ensure open
        const source = new EventSource('https://localhost:63349/scriptrunner-idea/connect', {withCredentials: true});

        source.addEventListener('message', function (e) {
            // todo:...
            // if (e.origin != 'http://example.com') {
            //     alert('Origin was not http://example.com');
            //     return;
            // }

            const clientActions = JSON.parse(e.data);

            // initial request we get the channel ID
            if ("channelId" in clientActions) {
                channelId = clientActions.channelId;

                console.log(clientActions);
                executionServerActionsViaHttp(channelId, serverActions);
            }
            else {
                // execute client actions on message
                if (Array.isArray(clientActions)) {
                    executeClientActions(clientActions);
                } else {
                    console.error("Expected an array of actions, got:", clientActions);
                }
            }
        }, false);

        source.addEventListener('open', function (e) {
            console.log("Connection was opened.");
            stopAllSpinners();
        }, false);

        source.addEventListener('error', function (e) {
            console.error("Connection error.");
            stopAllSpinners();

            $.ajax({
                type: "GET",
                url : "https://localhost:63342/"
            }).fail(function (e) {
                if (e.status === 404) {
                    window.require(['aui/flag'], function (flag) {
                        flag({
                            type : 'error',
                            title: 'IDEA Editor',
                            close: 'auto',
                            body : `We could not contact the ScriptRunner IDEA plugin. IDEA appears to be running but the ScriptRunner plugin is not installed.`
                        });
                    });
                } else {
                    window.require(['aui/flag'], function (flag) {
                        flag({
                            type : 'error',
                            title: 'IDEA Connection Failed',
                            close: 'manual',
                            body : `<p>1. Make sure that IntelliJ IDEA is running and the ScriptRunner plugin is installed.</p>
                                    <p>2. If you haven't trusted the certificate, <a href="https://localhost:63349/api/scriptrunner-idea/health" target="_blank">click here to open a new tab</a>, 
                                        and then click the link that says <i>Advanced</i>, and then <i>Proceed to localhost (unsafe)</i>. 
                                        More information is in <a href="https://scriptrunner.adaptavist.com/latest/jira/intellij-integration.html#_things_to_watch_out_for" target="_blank">our documentation</a>.</p>`
                        });
                    });
                }
            });

            source.close();

            if (source.readyState === EventSource.CLOSED) {
                console.log("Connection was closed.");
            }

        }, false);
    }
}

// Execute a list of server actions
function editorSpin(serverActions) {
    const editorSpec = serverActions[0].id;
    if (editorSpec) {
        const $editorStatus = getEditorStatus(editorSpec);
        if ($editorStatus) {
            $editorStatus.children().hide();
            $editorStatus.append(`<span class="aui-icon aui-icon-wait">Loading...</span>`);
        }
        return $editorStatus;
    }
    return null;
}

function editorStopSpin($editorStatus) {
    if ($editorStatus) {
        $editorStatus.find("span.aui-icon-wait").remove();
        $editorStatus.children().show();
    }
}

export function XexecuteServerActions(serverActions) {
    // for testing purposes redefine target url here
    actionsUrl = options.url + "/api/scriptrunner-idea/actions";

    if (serverActions.length) {
        const $editorStatus = editorSpin(serverActions);

        serverActions.forEach(function (action) {
            console.log("Server action:", action.name, action);
        });

        return $.ajax($.extend({}, defaultAjaxSettings, {
                url : actionsUrl,
                data: JSON.stringify(serverActions)
            })
        ).done(function (clientActions) {
            if (Array.isArray(clientActions)) {
                executeClientActions(clientActions);
            } else {
                console.error("Expected an array of actions, got:", clientActions);
            }
        }).fail(function (e, a, b) {
            console.log("Failed");
            // this not working
            // setEditorStatus(serverActions[0].id, "error");
        }).always(function () {
            editorStopSpin($editorStatus);
        });
    }
}

// Construct a server or client action
// Will accept an editorSpec or a id string (should be prefixed with a scheme, eg: inline:editor123.groovy, file:path/foo.groovy)
export function action(editorSpecOrId, name, params) {
    return $.extend({
        channelId: channelId,
        name     : name,
        id       : editorSpecOrId ? idea.getId(editorSpecOrId) : undefined
    }, params);
}

// Every request that performs a sync with server should be wrapped in this
export function sync(editorSpec, delay, fn) {
    clearTimeout(idea.getData(editorSpec, 'timer'));

    if (fn) {
        idea.setData(editorSpec, 'timer', setTimeout(fn, delay));
    } else {
        idea.removeData(editorSpec, 'timer');
    }
}
