
export const defaultAjaxSettings = {
    type: "POST",
    dataType: "json",
    contentType: "application/json"
};

export function initialiseToken(async) {

    // temp disabled
    var dfd = new $.Deferred();
    return dfd.resolve();

    // get token from server and store
    return $.ajax({
        type: "GET",
        async: async,
        dataType: "json",
        contentType: "application/json",
        url: ajsParams.baseURL + "/rest/scriptrunner/latest/idea/signingkey"
    }).done(function (data) {

        var expiry = new Date().getTime() + 9.5 * 60 * 1000; // 30s less than the server timeout

        $("#idea-token").remove();
        $('head').append($('<meta/>', {
            "id": "idea-token"
        }).attr('content', data["jwt"]).data("exp", expiry));
    });
}
