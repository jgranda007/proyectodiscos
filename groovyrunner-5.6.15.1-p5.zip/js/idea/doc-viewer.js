import {EDITOR_INIT} from "./constants";
import * as editorUtils from "./editor-utils.js";
import {followJavadocLink} from "./server-actions";
import {getEditor} from "./editor-utils";

require("wr-dependency!com.atlassian.auiplugin:dialog2");

$(document).on(EDITOR_INIT, initDocs);

let focusedEditor;

function getDocDialogId(editorSpec) {
    // currently we always return the same dialog for all editors
    return "editor-doc";
}

function getEditorFromInsideDialog(elem) {
    return editorUtils.getEditor($(elem).closest(".aui-dialog2").data("editorId"));
}

function initDocs(event) {
    const $editor = event.target;
    const dialogId = getDocDialogId($editor);
    let dialogEl = document.getElementById(dialogId);

    // Render hidden doc dialog (only one for all editors)
    if (!dialogEl) {
        $(com.adaptavist.idea.docDialog({id: dialogId})).appendTo(document.body);
        dialogEl = document.getElementById(dialogId);

        $(dialogEl)
        //                 .draggable({
        //                     handle: ".aui-dialog2-header"
        //                 })
        //                 .resizable({
        //                     handles: {
        //                         e: ".aui-dialog2-handle-right",
        //                         s: ".aui-dialog2-footer",
        //                         w: ".aui-dialog2-handle-left",
        //                         n: ".aui-dialog2-handle-top"
        //                     }
        //                 })
            .on("click", "a[href]", function (event) {
                event.preventDefault();
                const href = $(this).attr("href");
                followJavadocLink(getEditorFromInsideDialog(this), href);
            })
            .on("click", ".editor-doc-back", function (event) {
                event.preventDefault();
                const history = $(this).closest(".aui-dialog2").data("history") || [];
                history.pop();
                const href = history.pop();
                if (href) {
                    followJavadocLink(getEditorFromInsideDialog(this), href);
                }
            });

        // clear history when closing the dialog
        AJS.dialog2(dialogEl).on("hide", function () {
            $(dialogEl).removeData("history");
            // todo this is not working in jira
            setTimeout(function () {
                if (focusedEditor) {
                    focusedEditor.focus();
                }
            }, 300); // todo: some bug here, don't reduce timeout until fixed
        });
    }
}

export function showDoc(editorSpec, params) {
    focusedEditor = getEditor(editorSpec);
    const $dialog = $(document.getElementById(getDocDialogId(editorSpec)));

    const history = $dialog.data("history") || [];
    if (params.href) {
        history.push(params.href);
    }

    $dialog.find(".editor-doc-back").attr("aria-disabled", history.length < 2);

    $dialog.data("editorId", editorUtils.getId(editorSpec));
    $dialog.data("history", history);

    $dialog.find(" .aui-dialog2-content").html(params.content);
    $dialog.find(" .aui-dialog2-header-main").text(params.title || "Documentation");

    AJS.dialog2($dialog).show();
}

export function hideDoc(editorSpec) {
    AJS.dialog2("#" + getDocDialogId(editorSpec)).hide();
}
