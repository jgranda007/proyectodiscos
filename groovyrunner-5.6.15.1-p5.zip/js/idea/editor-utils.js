/**
 * editorSpec can be an Editor instance, the container element of the editor (raw Element or jQuery wrapped), or the id of an editor
 * @param editorSpec
 * @returns {*}
 */
export function getEditor(editorSpec) {
    if (!editorSpec) {
        throw new TypeError("getEditor: an editorSpec must be provided")
    }

    if (typeof editorSpec === "string" && editorSpec.startsWith("file:")) {
        return null;
    }

    return editorSpec.container ? editorSpec :
        ace.edit(editorSpec.jquery ? editorSpec[0] : editorSpec);
}

export function getEditorStatus(editorSpec) {
    if (!editorSpec) {
        throw new TypeError("getEditor: an editorSpec must be provided")
    }

    const editor = getEditor(editorSpec);
    if (! editor) {
        return null;
    }

    return $(editor.container)
        .closest(".editorControl")
        .find(".editor-status");
}

export function setEditorStatus(editorSpec, severity) {
    const $editorStatus = getEditorStatus(editorSpec);
    if (!! $editorStatus) {
        if (severity === "error") {
            const $span = $(`<span class="aui-icon aui-icon-small aui-icon-error" style="color: #d04437" 
                title="Errors found - might still work anyway">Error</span>`);
            $editorStatus.empty().append($span.tooltip());
        }
        else if (severity === "warning") {
            const $span = $(`<span class="aui-icon aui-icon-small aui-icon-warning" style="color: #f6c342" 
                title="Warnings found, don't worry about it too much">Warning</span>`);
            $editorStatus.empty().append($span.tooltip());
        }
        else if (severity === "ok") {
            const $span = $(`<span class="aui-icon aui-icon-small aui-iconfont-approve" style="color: green" 
                title="Looks good">OK</span>`);
            $editorStatus.empty().append($span.tooltip());
        }
        else if (severity === "wait") {
            $editorStatus.empty().append(`<span class="aui-icon aui-icon-wait">Loading...</span>`);
        }
        else {
            throw "Unhandled status";
        }


        // $editorStatus.find("span.aui-icon-small").tooltip();
    }
}

export function setToolbarMessage(editorSpec, message) {
    $(getContainer(editorSpec)).closest(".editorControl").find("[role=toolbar]").find(".editor-message").html(message);
}

export function getContainer(editorSpec) {
    if (!editorSpec) {
        throw new TypeError("getContainer: an editorSpec must be provided")
    }
    return $(editorSpec.container || (typeof editorSpec === "string" ? document.getElementById(editorSpec) : editorSpec));
}

export function getId(editorSpec) {
    if (!editorSpec) {
        throw new TypeError("getId: an editorSpec must be provided")
    }
    return typeof editorSpec === "string" ? editorSpec :
        (editorSpec.container ? editorSpec.container.id :
            (editorSpec.jquery ? editorSpec[0].id : editorSpec.id));
}

export function getData(editorSpec, key) {
    return getContainer(editorSpec).data(key);
}

export function setData(editorSpec, key, value) {
    getContainer(editorSpec).data(key, value);
}

export function removeData(editorSpec, key) {
    getContainer(editorSpec).removeData(key);
}

export function removeMarkers(editorSpec, className) {
    var editor = getEditor(editorSpec);

    $.each(editor.session.getMarkers(), function (key, marker) {
        if (marker.clazz.includes(className)) {
            editor.session.removeMarker(marker.id);
        }
    });
}

