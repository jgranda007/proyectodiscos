import * as idea from "./editor-utils.js";
import {action, executeServerActions, sync} from "./action-utils.js";
import $ from "jquery";
import {serializeQueryString} from "../behaviours/serialiseQueryString";

//
// Server Actions
//
// These functions are triggered from Editor bindings or other user interaction, to begin an operation,
// usually an async http request or other retrieval of data, which may eventually result in an action being triggered.
// They shouldn't really interact with the DOM.
//

export function syncAndExecuteServerActions(editorSpec, serverActions, delay) {
    sync(editorSpec, delay || 0, function () {
        executeServerActions([serverSetContent(editorSpec)].concat(serverActions));
    });
}

function serverSetContent(editorSpec) {
    const editor = idea.getEditor(editorSpec);
    const document = editor.getSession().getDocument();
    let selection;

    if (!editor.selection.isEmpty()) {
        const selectedRange = editor.selection.getRange();
        selection = {
            start: document.positionToIndex(selectedRange.start),
            end: document.positionToIndex(selectedRange.end)
        };
    }

    return action(editor, "SetContent", {
        "deserialiseToClass": "com.adaptavist.idea.rest.server.SetContentAction",
        content: editor.getValue(),
        selection: selection,
        offset: document.positionToIndex(editor.getCursorPosition())
    });
}

function setBindings(editorSpec) {
    return action(editorSpec, "SetBindings", {
        "deserialiseToClass": "com.adaptavist.idea.rest.server.SetBindingsAction",
        bindVars: idea.getData(editorSpec, "bindings")
    });
}

function delayedLint(editorSpec) {

    const serverActions = [
        action(editorSpec, "Lint", {
            "deserialiseToClass": "com.adaptavist.idea.rest.server.LintAction"
        }),
    ];

    // get parameters again if it's already being displayed
    if ($(".aui-inline-dialog:visible").length > 0) {
        serverActions.push(action(editorSpec, "ShowParameterInfo"));
    }

    syncAndExecuteServerActions(editorSpec, serverActions, 1000);
}

function lintFiles(paths) {
    paths.map(function (path) {
        const editorSpec = "file:" + path;

        getBindingInfo(editorSpec).done(function (bindVars) {
            idea.setData(editorSpec, "bindings", bindVars);

            return executeServerActions([
                setBindings(editorSpec),
                action(editorSpec, "Lint", {
                    "deserialiseToClass": "com.adaptavist.idea.rest.server.LintAction"
                })
            ]);
        });
    })
}

function fetchCompletions(editorSpec, params) {
    syncAndExecuteServerActions(editorSpec, [
        action(editorSpec, "GetCompletion", params)
    ]);
}

function selectLookupItem(editorSpec, selectionIdx, completionType) {
    syncAndExecuteServerActions(editorSpec, [
        action(editorSpec, "SelectLookupItem", {
            selectionIdx: selectionIdx,
            completionType: completionType
        })
    ]);
}

function fetchParameters(editorSpec) {
    syncAndExecuteServerActions(editorSpec, [
        action(editorSpec, "ShowParameterInfo")
    ]);
}

// currently unused but will be called from menu item
function optimiseImports(editorSpec) {
    syncAndExecuteServerActions(editorSpec, [
        action(editorSpec, "OptimiseImports")
    ]);
}

function reformatCode(editorSpec) {
    syncAndExecuteServerActions(editorSpec, [
        action(editorSpec, "ReformatCode")
    ]);
}

function selectWord(editorSpec) {
    syncAndExecuteServerActions(editorSpec, [
        action(editorSpec, "SelectWord")
    ]);
}

function executeQuickFix(editorSpec, fixText) {
    syncAndExecuteServerActions(editorSpec, [
        action(editorSpec, "QuickFix", {
            fix: fixText
        })
    ]);
}

function navigateToDeclaration(editorSpec) {
    syncAndExecuteServerActions(editorSpec, [
        action(editorSpec, "NavigationHandler")
    ]);
}

function fetchJavadoc(editorSpec) {
    syncAndExecuteServerActions(editorSpec, [
        action(editorSpec, "GetJavadoc")
    ]);
}

function followJavadocLink(editorSpec, href) {
    executeServerActions([
        action(editorSpec, "GetJavadoc", {
            href: href
        })
    ])
}

function fetchEditorStatus(editorSpec) {
    executeServerActions([
        action(editorSpec, "EditorStatus", {
            "deserialiseToClass": "com.adaptavist.idea.rest.server.EmptyServerAction",

        })
    ]);
}

// Other actions

function fetchQuickFixes(editorSpec) {
    syncAndExecuteServerActions(editorSpec, [
        action(editorSpec, "ShowIntentionActions")
    ]);
}

function getBindingInfo(editorSpec) {
    const myOpts = idea.getData(editorSpec, "sr-context-options");
    const contextOptions = typeof (myOpts) === "string" ? myOpts : JSON.stringify(myOpts);
    return $.ajax({
        type: "POST",
        url: `${AJS.contextPath()}/rest/scriptrunner-jira/latest/diagnostics/binding?${serializeQueryString(context)}`,
        data: {
            "contextOptions": contextOptions
        },
        dataType: "json",
        contentType: "application/json"
    });
}

function openInIde(params) {
    executeServerActions(
        action(null, "OpenInIde", params)
    )
}

function sendHostData(params) {
    executeServerActions(
        action(null, "SendHostData", params)
    )
}

function sendScriptRootsResponse(params) {
    console.log("Sending Script Roots Response", params);
    executeServerActions(
        action(null, "SyncScriptRoots", params)
    )
}

function initBindings(editorSpec) {
    getBindingInfo(editorSpec).done(function (bindVars) {
        idea.setData(editorSpec, "bindings", bindVars);

        syncAndExecuteServerActions(editorSpec, [
            setBindings(editorSpec),
            action(editorSpec, "Lint", {
                "deserialiseToClass": "com.adaptavist.idea.rest.server.LintAction"
            })
        ])
    }).fail(function (e, f, g) {
        console.error("initBindings failed", g);
    });
}

export {
    serverSetContent,
    setBindings,
    delayedLint,
    lintFiles,
    fetchCompletions,
    selectLookupItem,
    fetchParameters,
    optimiseImports,
    sendHostData,
    executeQuickFix,
    navigateToDeclaration,
    fetchJavadoc,
    followJavadocLink,
    fetchEditorStatus,
    fetchQuickFixes,
    initBindings,
    reformatCode,
    selectWord,
    openInIde,
    sendScriptRootsResponse
}
