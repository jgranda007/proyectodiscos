import {EDITOR_INIT} from "./constants";
import * as editorUtils from "./editor-utils";
import {getEditor} from "./editor-utils";

// marker whether we should let the component be destroyed without saving
let scriptsAreDirty = false;

(function($){
    $.event.special.destroyed = {
        remove: function(o) {
            if (o.handler) {
                o.handler()
            }
        }
    }
})($);

$(window).on("beforeunload", function () {
    if (scriptsAreDirty) {
        // generic message shown in Chrome and FF
        return("Unsaved changes, are you sure you want to leave?")
    }
});

// todo: Should be ScriptRunner.Events.etc
$(document).on("scriptexecutedsuccess", function () {
    scriptsAreDirty = false;
});

$(document).on(EDITOR_INIT, initChecks);

function initChecks(event) {
    const $editor = event.target;
    const editor = getEditor($editor);

    editor.session.on('change', function () {
        scriptsAreDirty = true;
    });

    editorUtils.getContainer(editor).bind('destroyed', function() {
        scriptsAreDirty = false;
    });
}
