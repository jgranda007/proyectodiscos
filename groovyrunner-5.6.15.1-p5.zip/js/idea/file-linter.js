/**
 * Shared file - responsible for kicking off linting on files
 */
import {lintFiles} from "./server-actions.js";
import _ from "lodash";

const reinitialiseAll = function () {
    codeCheckFiles();
};

function codeCheckFiles() {

    // only files listed here - note that codemirror will kick off the linting for each CM instance
    let remoteValidations = [];
    $(".scriptFileSource").not("[data-sr-complete=true]").each(function () {
        const $scriptFileSource = $(this);

        const $info = $scriptFileSource.parent().find("div.scriptInfo");
        const $rag = $scriptFileSource.parent().find("span.rag");

        let scriptFile;
        if ($scriptFileSource.is("input")) {
            if ($scriptFileSource.val().length > 0) {
                scriptFile = $scriptFileSource.val();
            }
            else {
                $rag.removeClass("sr-ok sr-warning sr-error").removeAttr("data-compiler");
                $info.empty();
            }
        }
        else {
            scriptFile = $scriptFileSource.data("scriptfile")
        }

        // hack - multiple users for ID
        if (!!scriptFile) {
            $scriptFileSource.attr("id", "file:" + scriptFile);

            remoteValidations.push({
                scriptFile: scriptFile,
                info: $info,
                rag: $rag,
                context: $scriptFileSource.data("sr-context"),
                options: $scriptFileSource.data("sr-context-options")
            });
        }

        // watch text inputs for changes
        $scriptFileSource.off("input paste").on("input paste", _.debounce(function () {
            $(this).attr('data-sr-complete', 'false');
            codeCheckFiles();
        }, 1000));
    });

    if (remoteValidations.length > 0) {
        // we need to sent a list of lists, so we can receive a single param as a list
        lintFiles(remoteValidations.map(function (data) {
            return data.scriptFile
        }));

        // $(document).trigger("/compile", [remoteValidations]);
    }
}

export function onDocumentReady() {
    $(document).on("/start", function () {
        reinitialiseAll();
    });

    reinitialiseAll();
}

$(function () {
    setTimeout(onDocumentReady, 200);
});
