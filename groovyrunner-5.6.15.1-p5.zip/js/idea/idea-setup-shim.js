(function ($) {
    let $testArea = $("#ratpack-idea-testing");
    $testArea.find("#setup-form-soy-target").html(plugin.com.onresolve.scriptrunner.project.enableIdeaForm({
        ideaOptions: WRM.data.claim('com.onresolve.jira.groovy.groovyrunner:directIdeaIntegration.idea-editor-data-provider')
    }));

    $testArea.find(".idea-script-file").each(function (idx) {
        const $editForm = $(this);
        const params = $(this).data("params");
        $editForm.append(ScriptRunner.Templates.Params.checkedScriptFileInputBox(params));
    });
})($);