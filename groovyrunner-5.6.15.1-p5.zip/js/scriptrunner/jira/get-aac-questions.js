require('../../jquery.livequery');

(function ($, _, AJS) {
    function updateQuestionsPanel($context) {
        var $aac = $context.find("#aac-questions-placeholder");

        if ($aac.length > 0) {
            $aac.removeAttr("id");
            AJS.$.ajax({
                type: "GET",
                url: AJS.contextPath() + "/rest/scriptrunner/latest/custom/fetchSimilarQuestions",
                data: $aac.data("reporter")
            }).fail(function (XMLHttpRequest, textStatus, errorThrown) {
                $aac.empty().append("Failed to get questions: " + errorThrown);
            }).done(function (data) {
                $aac.empty().append(data);
            })
        }
    }

    JIRA.bind(JIRA.Events.NEW_CONTENT_ADDED, function (event, $context, reason) {

        // hack for JA, which emits no events - https://jira.atlassian.com/browse/JSW-13527
        // When only supporting IE11+ switch to MutationObserver, or expire and re-add the livequery
        if (window.location.href.indexOf("RapidBoard.jspa?") > -1) {
            $("#ghx-detail-issue").livequery(function() {
                updateQuestionsPanel($context);
            });
        }

        if (reason === JIRA.CONTENT_ADDED_REASON.pageLoad || reason === JIRA.CONTENT_ADDED_REASON.panelRefreshed ) {
            updateQuestionsPanel($context);
        }
    });

})(AJS.$, _, AJS);
