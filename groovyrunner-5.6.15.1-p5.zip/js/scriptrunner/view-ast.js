require("jquery.fancytree/dist/skin-win7/ui.fancytree.css");
require("jquery.fancytree/dist/jquery.fancytree-all-deps.min");

(function ($, _, AJS) {
    var getAst = function() {
        var data = {};
        AJS.$.ajax({
            type: "POST",
            // dataType: "json",
            url: AJS.contextPath() + "/rest/scriptrunner/latest/user/viewast",
            data: AJS.$(window.opener.document).find("#script-runner-form").serialize() + "&phase=" + $("#phase").val(),
            beforeSend: function (request) {
                request.setRequestHeader("X-Atlassian-token", "no-check");
            }
        }).fail(function (XMLHttpRequest, textStatus, errorThrown) {
            console.warn("failed AST analysis, check server logs");
        }).done(function(resp) {

            $("#decomp").empty().html(resp.decomp);
            $("#bytecode").empty().html(resp.bytecode);

            var $tree = $("#ast-tree-container");
            $tree.empty().html('<div id="ast-tree" class="sampletree" ></div>');
            $("#ast-tree").fancytree({
                source: resp.tree.children,
                activate: function(event, data) {
                    $("#props").empty().html(plugin.com.onresolve.scriptrunner.astProperty({rows: data.node.data.properties}).content);
                }
            });

            $("ul.fancytree-container").css("height", "200px");
        });
    };

    $(function () {
        $("#phase").on("change", getAst);
        $(getAst);
    })
})(AJS.$, _, AJS);
