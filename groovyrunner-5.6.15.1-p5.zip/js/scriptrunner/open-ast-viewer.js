(function ($, _, AJS) {
    $(function() {

        $("a.view-ast").on("click", function () {
            var w = window.open(AJS.contextPath() + "/plugins/servlet/scriptrunner/viewast", "popupWindow", "width=1200, height=800, scrollbars=yes");
        })

    });

})(AJS.$, _, AJS);
