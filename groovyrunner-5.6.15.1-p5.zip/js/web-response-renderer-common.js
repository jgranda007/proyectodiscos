require('wr-dependency!com.atlassian.auiplugin:ajs');
require('wr-dependency!com.atlassian.auiplugin:dialog2');
require('wr-dependency!web-item-response-renderer');
require('./web-response-renderer');
