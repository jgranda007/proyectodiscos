function isRequiredField($field) {

}

export function getDescription($field) {
    const $fieldGroup = $field.closest("div.field-group");
    return $fieldGroup.find(".field-container").next("div.description").text()
}