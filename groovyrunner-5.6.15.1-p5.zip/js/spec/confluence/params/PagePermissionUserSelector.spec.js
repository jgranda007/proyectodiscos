import * as React from "react";
import {mount} from "enzyme";
import PagePermissionUserSelector
    from "../../../admin/params/pagePermissionUserSelector/components/PagePermissionUserSelector";
import {Provider} from "react-redux";
import configureStore from "../../../admin/configureStore";
import {permissionLevelSelected} from "../../../admin/params/pagePermissionUserSelector/actionsAndReduces/PagePermissionsActions";


export const PagePermissionUserSelectorSpec = () => {

    return describe('Page Permission User Selector Component Test', () => {

        it('renders in initial state success test', () => {

            const store = configureStore(state);

            const reactWrapper = mount(
                <Provider store={store}>
                    <PagePermissionUserSelector/>
                </Provider>
            );

            // with select space drop-down
            expect(reactWrapper.find('SpacePickerParam').length).toEqual(1);
            expect(reactWrapper.find('Tree').length).toEqual(0);

            // with permission level drop
            expect(reactWrapper.find('PermissionsOptions').length).toEqual(1);
            // permission level "no restrictions";

            // no group box
            expect(reactWrapper.find('GroupsPicker').length).toEqual(0);

            // no user box
            expect(reactWrapper.find('UserPicker').length).toEqual(0);

        });

        it('renders in "editing restrictions" state success test', () => {

            const store = configureStore(state);

            const reactWrapper = mount(
                <Provider store={store}>
                    <PagePermissionUserSelector/>
                </Provider>
            );

            store.dispatch(permissionLevelSelected({permission: "EDITING_RESTRICTED"}));
            reactWrapper.mount();

            // with select space drop-down
            expect(reactWrapper.find('SpacePickerParam').length).toEqual(1);
            expect(reactWrapper.find('Tree').length).toEqual(0);

            // with permission level drop
            expect(reactWrapper.find('PermissionsOptions').length).toEqual(1);


            // with group box
            expect(reactWrapper.find('GroupsPicker').length).toEqual(1);
            expect(reactWrapper.find('GroupsPicker').text()).toContain("The groups of users that can edit");

            //with user box
            expect(reactWrapper.find('UserPicker').length).toEqual(1);
            expect(reactWrapper.find('UserPicker').text()).toContain("The individual users that can edit");

        });

        it('renders in "viewing and editing restrictions" state success test', () => {

            const store = configureStore(state);

            const reactWrapper = mount(
                <Provider store={store}>
                    <PagePermissionUserSelector/>
                </Provider>
            );

            store.dispatch(permissionLevelSelected({permission: "VIEWING_AND_EDITING_RESTRICTED"}));
            reactWrapper.mount();

            // with select space drop-down
            expect(reactWrapper.find('SpacePickerParam').length).toEqual(1);
            expect(reactWrapper.find('Tree').length).toEqual(0);

            // with permission level drop
            expect(reactWrapper.find('PermissionsOptions').length).toEqual(1);

            // with group box
            expect(reactWrapper.find('GroupsPicker').length).toEqual(1);
            expect(reactWrapper.find('GroupsPicker').text()).toContain("The groups of users that can view and edit");

            // with user box
            expect(reactWrapper.find('UserPicker').length).toEqual(1);
            expect(reactWrapper.find('UserPicker').text()).toContain("The individual users that can view and edit");
        })
    });
};

const state = {
    ui            : {
        cancel : {
            title: 'Cancel'
        },
        submit : {
            title: 'Run'
        },
        preview: {
            title: 'Preview'
        }
    },
    items         : [],
    validation    : {},
    console       : {
        scriptText: '',
        scriptFile: ''
    },
    builtins      : [
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.AddPageRestrictions',
            name         : 'Add/Remove Restrictions to Parent & Child Pages',
            description  : 'This script allows you to add and remove the viewing and editing restrictions to a given page and all of its descendants at the same time.',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/confluence/builtin-scripts.html#_add_remove_restrictions_to_parent_child_pages'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.BulkAddRemoveLabels',
            name         : 'Bulk Add/Remove Labels on One or More Pages',
            description  : 'Add or remove Labels on the selected page trees',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/confluence/builtin-scripts.html#_bulk_add_remove_labels_on_one_or_more_pages'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.BulkDeleteAttachments',
            name         : 'Bulk Delete Attachments',
            description  : 'Deletes all attachments of one or more pages',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/confluence/builtin-scripts.html#_bulk_delete_attachments'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.BulkDeleteComments',
            name         : 'Bulk Delete Comments from One or More Pages',
            description  : 'Deletes all comments older than the specified age from the selected pages',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/confluence/builtin-scripts.html#_bulk_delete_comments'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.BulkEmptyTrash',
            name         : 'Bulk Purge Trash',
            description  : 'Bulk purge trash for multiple spaces',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/confluence/builtin-scripts.html#_bulk_purge_trash'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.ChangeContentAuthor',
            name         : 'Change content author',
            description  : 'Change the author for multiple pieces of content',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/confluence/builtin-scripts.html#_change_content_author'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.CopySpace',
            name         : 'Copy Space',
            description  : 'Copies a space to a new space',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/confluence/builtin-scripts.html#_copy_space'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.CopyTree',
            name         : 'Copy Page Tree',
            description  : 'Copy a page tree from one root to another',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/confluence/builtin-scripts.html#_copy_page_tree'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.NonWikiLinkConverter',
            name         : 'Convert absolute URLs to Confluence content to Confluence links',
            description  : 'Converts fully-qualified URLs to proper Confluence URLs, which allows incoming links and page name change tracking to work properly',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/confluence/builtin-scripts.html#_convert_urls_to_confluence_links'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.PageInheritPermissions',
            name         : 'Inherit Restrictions for Pages',
            description  : 'Automatically sets the restrictions of a new page based on the parent page',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/confluence/builtin-scripts.html#_inherit_restrictions_for_pages'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.RenameLabels',
            name         : 'Rename labels',
            description  : 'Renames labels in bulk',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/confluence/builtin-scripts.html#_rename_labels'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.SpaceStats',
            name         : 'Space Statistics',
            description  : 'Shows space related statistics',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/confluence/builtin-scripts.html#_space_statistics'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.SwitchUser',
            name         : 'Switch to a different user',
            description  : 'Switch to another user to deal with support problems and so on\n        ',
            homePlugin   : null,
            hideInitially: false
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.TreeDelete',
            name         : 'Delete Page Tree',
            description  : 'Deletes an entire page tree',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/confluence/builtin-scripts.html#_delete_a_page_tree'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.confluence.admin.XPathSearcher',
            name         : 'XPath Search in Pages',
            description  : 'Use xpath expressions to find matching pages',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/confluence/builtin-scripts.html#_xpath_search_in_pages'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.common.admin.ConfigurationExporter',
            name         : 'Configuration exporter',
            description  : 'Exports extension configuration information to a descriptor file for using in a scripts plugin',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/jira/builtin-scripts.html#todo...'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.common.admin.ListScheduledJobs',
            name         : 'List scheduled jobs',
            description  : 'List all scheduled jobs',
            homePlugin   : null,
            hideInitially: false
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.common.admin.LogFileViewer',
            name         : 'View server log files',
            description  : 'Shows the last N lines of application log files',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/jira/builtin-scripts.html#_view_server_log_files'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.common.admin.RunUnitTests',
            name         : 'Test runner',
            description  : 'Runs JUnit and Spock tests, for use in a development instance only',
            homePlugin   : null,
            hideInitially: false,
            helpUrl      : 'http://localhost:4000/jira/testing.html'
        },
        {
            'class'      : 'com.onresolve.scriptrunner.canned.common.admin.TransformationsCannedScript',
            name         : 'Sample showing transforms',
            description  : 'Sample showing transforms',
            homePlugin   : null,
            hideInitially: false
        }
    ],
    edit          : {
        'canned-script': 'com.onresolve.scriptrunner.canned.confluence.admin.AddPageRestrictions',
        pages          : [],
        permissionLevel: 'NO_RESTRICTIONS',
        groups         : [],
        users          : []
    },
    result        : null,
    editParams    : [
        {
            name: 'PAGE_PERMISSION_USER_SELECTOR',
            type: 'pagePermissionUserSelector'
        },
        {
            name              : 'FIELD_FUNCTION_ID',
            label             : 'Function ID',
            description       : 'A hidden function ID.',
            type              : 'text',
            fieldRowCssClasses: 'hidden'
        }
    ],
    loading       : {
        builtins  : null,
        params    : null,
        configured: null
    },
    context       : {},
    flag          : null,
    pagePermission: {
        pages      : [],
        permissions: 'NO_RESTRICTIONS',
        groups     : [],
        users      : []
    },
    routing       : {
        location: {
            pathname: '/builtin/exec/com.onresolve.scriptrunner.canned.confluence.admin.AddPageRestrictions',
            search  : '',
            hash    : '',
            key     : 'x8g84x'
        }
    }
};