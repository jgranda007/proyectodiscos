///<reference path="../../../../../../node_modules/@types/jasmine/index.d.ts"/>
///<reference path="../../../../../../node_modules/@types/jasmine-jquery/index.d.ts"/>
'use strict';

import {moveJasmineStuffToTop, nextTick, removeDirtyFormWarning} from "../utils/test-utils";
import {Behaviours} from "../../behaviours/index";
import 'wr-dependency!js-test-resources'

/**
 * Test fields that are made up of several inputs
 */
describe("submit validation", () => {

    const JBHV = new Behaviours();

    beforeAll(removeDirtyFormWarning);
    afterAll(moveJasmineStuffToTop);

    it("can't submit when fields are required", async () => {
        let fieldId = "environment";
        let $field = $(`#${fieldId}`);
        const $form = $field.closest("form");

        JBHV.addFieldListeners($form, {
            [fieldId]: {
                field    : $field,
                validator: "server",
                required : true,
            },
        });

        $form.submit();

        await nextTick();
        expect($field.val()).toBeFalsy();
        expect($field.closest('div.field-group').find(".jbhverror")).toExist();
    });
});
