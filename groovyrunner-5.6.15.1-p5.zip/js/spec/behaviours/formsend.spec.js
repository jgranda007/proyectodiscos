///<reference path="../../../../../../node_modules/@types/jasmine/index.d.ts"/>
///<reference path="../../../../../../node_modules/@types/jasmine-jquery/index.d.ts"/>
'use strict';

import {moveJasmineStuffToTop, removeDirtyFormWarning, whenResetTriggered} from "../utils/test-utils";
import {default as deep} from 'deep-diff'
import {Behaviours} from "../../behaviours/index";
import 'wr-dependency!js-test-resources'

// experimental way of better getting form data, doesn't work on IE 11
xdescribe("serialising form", () => {

    const JBHV = new Behaviours();

    beforeAll(removeDirtyFormWarning);
    afterAll(moveJasmineStuffToTop);

    function constructFormNew(docRoot) {

        let form;

        // this means that the doc root is already a form.aui
        if ($(docRoot).is("form.aui"))
            form = $(docRoot)[0];
        else {
            form = docRoot.find("form.aui")[0];
        }

        const formData = new FormData(form);

        const result = {};
        for (let {name, type, classList} of Array.from(form.elements)) {
            let multipleType = (type === 'select-multiple' && !classList.contains('aui-ss-select')) || type === 'checkbox';

            result[name] = multipleType ? formData.getAll(name) : formData.get(name);

            // handle cascading selects
            // if (classList.contains("cascadingselect-parent")) {
            //     const tmp = elem.parent().find("option:selected").map(function () {
            //         return $(this).val();
            //     });
            //     myform[elem.attr("name")] = $.makeArray(tmp).join("-*-*-");
            // }

        }

        return result;
    }

    it("tests form data", async () => {

        const fieldId = 'components';
        const $field = $('#components');
        const $assigneeFld = $("#assignee");

        JBHV.addFieldListeners($field.closest("form"), {
            [fieldId]: {
                field    : $field,
                fieldType: 'com.atlassian.jira.issue.fields.ComponentsSystemField',
                setValue : ["10000", "10001"],
            },
            assignee : {
                field    : $assigneeFld,
                fieldType: 'com.atlassian.jira.issue.fields.AssigneeSystemField',
                setValue : "anuser",
            },
        }, true);

        $(document).on("dumpform", () => {
        });

        await whenResetTriggered($assigneeFld);

        const result = constructFormNew($field.closest("form"));

        // select multiple but shd be single
        expect(result["assignee"]).toEqual('anuser');
        expect(result["components"]).toEqual(["10000", "10001"]);

        const cResult = JBHV.constructForm($field.closest("form"));
        console.log(JSON.stringify(cResult));

        // var deep = require('deep-diff');
        // console.log(deep);
        console.log(deep.diff(cResult, result));

        // try console.log($(form).serialize())
        // and https://github.com/kflorence/jquery-deserialize
    });

    it("tests diffing behaviours", () => {

        const b1 = {
            components : {
                fieldType: 'com.atlassian.jira.issue.fields.ComponentsSystemField',
                setValue : ["10000", "10001"],
                readonly: false,
            },
        };
        const b2 = {
            components : {
                fieldType: 'com.atlassian.jira.issue.fields.ComponentsSystemField',
                setValue : ["10000", "10001"],
                readonly: true,
            },
        };

        console.log(deep.diff(b1, b2));


        deep.observableDiff(b1, b2, function (d) {
            // Apply all changes except those to the 'name' property...
            // if (d.path.length !== 1 || d.path.join('.') !== 'name') {
            //     applyChange(lhs, rhs, d);
            // }

            console.log(d);
        });

    })
});
