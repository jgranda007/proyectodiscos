'use strict';

import 'wr-dependency!js-test-resources'

describe("field decorators", () => {
    beforeAll(async () => {
        $("form.aui").addClass("ajs-dirty-warning-exempt");
    });

    it("adds listeners", () => {
        window.ScriptRunner.Behaviours.enableDevTools().then(() => {
            window.ScriptRunner.Behaviours.disableDevTools()
        });
        expect().nothing();
    });
});
