describe("running the script console", function () {

    beforeEach(function (done) {
        spyOn(AJS.$, "ajax").and.callFake(function (params) {

            if (/Checker$/.test(params.url)) {

                return $.when({
                    compilationResult: {
                        "syntaxExceptions": [
                            {
                                "startColumn": 1,
                                "sourceLocator": "Script114.groovy",
                                "suppressed": [],
                                "message": "[Static type checking] - No such property: estimy for class: com.atlassian.jira.issue.Issue\n @ line 1, column 1.",
                                "endLine": 1,
                                "stackTraceDepth": 247,
                                "cause": null,
                                "originalMessage": "[Static type checking] - No such property: estimy for class: com.atlassian.jira.issue.Issue\n",
                                "fatal": false,
                                "localizedMessage": "[Static type checking] - No such property: estimy for class: com.atlassian.jira.issue.Issue\n @ line 1, column 1.",
                                "endColumn": 14,
                                "line": 1,
                                "startLine": 1
                            }
                        ],
                        "warnings": []
                    }
                }, "some text status", {status: 200});

            }
            else if (params.dataType !== "script") {
                var data = {"output": "4"};
                return $.when(data, "some text status", {status: 200});
            }
            else {
                return $.ajax(params)
            }
        });

        spyOn($, "ajax").and.callFake(function (params) {

            if (params.dataType !== "script") {
                var data = {"output": "4"};
                return $.when(data, "some text status", {status: 200});
            }
            else {
                return $.ajax(params)
            }
        });

        ScriptRunner.Base.isScriptConsole = function () { return true; };

        $("body").append((plugin.com.onresolve.scriptrunner.project({
            baseUrl: "/",
            isBuiltin: false,
            section: "script_console",
            title: "scripts"
        })));

        done();
    });

    xit("running a visualisation that requires visjs", function (done) {


        ScriptRunner.Base.isScriptConsole = function () { return true; };
        ScriptRunner.Base.toggleAdvancedMode();

        $("#scriptText").val("1 + 3");
        $("#jsLibs option").filter(function() {return $(this).text() == "visjs"}).prop('selected', true);

        var $runscript = $("#runscript");
        $runscript.off('click').on('click', ScriptRunner.Base.runScript);

        $("#htmlText").val('<link href="http://visjs.org/dist/vis.css" rel="stylesheet" type="text/css" />\n\n' +
        '<div id="visualization"></div>');

        $("#jsText").val("    var container = document.getElementById('visualization');\n" +
            "  var items = [\n" +
            "    {x: '2014-06-11', y: 10},\n" +
            "    {x: '2014-06-12', y: 25},\n" +
            "    {x: '2014-06-13', y: 30},\n" +
            "    {x: '2014-06-14', y: 10},\n" +
            "    {x: '2014-06-15', y: 15},\n" +
            "    {x: '2014-06-16', y: 30}\n" +
            "  ];\n" +
            "\n" +
            "  var dataset = new vis.DataSet(items);\n" +
            "  var options = {\n" +
            "    start: '2014-06-10',\n" +
            "    end: '2014-06-18'\n" +
            "  };\n" +
            "  var graph2d = new vis.Graph2d(container, dataset, options);"
        );

        // to receive the event this needs to be the same jquery, ie AJS.$ not $
        AJS.$(document).one(ScriptRunner.Events.SCRIPT_EXECUTED_SUCCESS, function () {
            expect ($("#result")).toContainElement("div.vis");
            done()
        });

        $runscript.click();

        console.log("result: ", $("#result").text());
    });

    // test disabled because it's making poxy sauceconnect fail
    xit("running a vis using gitgraph", function (done) {

        ScriptRunner.Base.isScriptConsole = function () { return true; };
        ScriptRunner.Base.toggleAdvancedMode();

        $("#scriptText").val("1 + 3");
        $("#jsLibs option").filter(function() {return $(this).text() == "gitgraph"}).prop('selected', true);

        var $runscript = $("#runscript");
        $runscript.off('click').on('click', ScriptRunner.Base.runScript);

        $("#htmlText").val('<link href="https://cdn.rawgit.com/nicoespeon/gitgraph.js/v1.0.1/build/gitgraph.css" rel="stylesheet" type="text/css" />\n\n' +
        '<canvas id="visualization"></canvas>');

        $("#jsText").val("var gitgraph = new GitGraph({\n" +
            "    template: \"metro\",\n" +
            "    orientation: \"vertical\",\n" +
            "    mode: \"compact\",\n" +
            "    elementId: \"visualization\"\n" +
            "});\n" +
            "var master = gitgraph.branch(\"master\");\n" +
            "gitgraph.commit();\n" +
            "var develop = master.branch(\"develop\");\n" +
            "var xdevelop = master.branch(\"xdevelop\");\n" +
            "xdevelop.commit().commit();\n" +
            "develop.commit().commit();\n" +
            "master.commit();\n" +
            "develop.merge(master);\n" +
            "xdevelop.merge(master);\n" +
            "master.commit();"

        );

        // to receive the event this needs to be the same jquery, ie AJS.$ not $
        AJS.$(document).one(ScriptRunner.Events.SCRIPT_EXECUTED_SUCCESS, function () {
            // expect ($("#result")).toContainElement("div.vis");
            done()
        });

        $runscript.click();
    });

    xit("testing when", function (done) {

        var jsLibs = ["http://cdnjs.cloudflare.com/ajax/libs/vis/3.9.1/vis.jsX", "http://cdnjs.cloudflare.com/ajax/libs/d3/3.5.5/d3.min.js"];

        var scriptFetchers = jsLibs.map(function (url) {
            return $.ajax({
                url: url,
                cache: true
            }).fail(function (jqxhr, textStatus, status) {
                console.log("js download failed on: " + url, textStatus);
            })
        });

        $.when.apply($, scriptFetchers).done(function (data) {
            console.log("got all modules");
        }).done(function () {
            console.log("done again");
        }).fail(function (jqxhr, textStatus, status) {
            console.log("failed", textStatus);
        }).always(function () {
            console.log("always");
            done();
        })
    });

    // not working
    xit("testing script console decoration", function () {

        $("#scriptText").val("1 + 4");
        console.log($("#scriptText").val());

        expect($("#check").length).toEqual(1);
        $("#check").click();

        // todo: test that the gutter markers are there.
    })
});

