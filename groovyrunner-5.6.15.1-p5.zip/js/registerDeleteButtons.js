(function ($) {
    require("qtip2");
    require("qtip2/dist/jquery.qtip.min.css");
    if (typeof ScriptRunner === "undefined") {
        window["ScriptRunner"] = {};
    }

    function buildDeleteLinkRegistrationHandler(positionTargetClass, showTargetClass, childSelectorForId, positionMy, positionAt) {
        return function (index, element) {
            var $element = $(element);
            var configuredItemId = childSelectorForId ?
                $element.find(childSelectorForId).attr('rel') :
                $element.attr('rel');
            $element.qtip({
                content: '<div class="qtip-aui-dialog-clone"><p>Confirm deletion of this configured item</p>' +
                '<button class="aui-button configured-item-confirm" data-inline-dialog-id=' + configuredItemId +
                '>Delete</button><button class="aui-button configured-item-confirm">Cancel</button></div>'
                ,
                position: {
                    my: positionMy || 'top right',
                    at: positionAt || 'bottom left',
                    target: $(positionTargetClass + configuredItemId)
                },
                show: {
                    solo: true,
                    target: $(showTargetClass + configuredItemId),
                    event: 'click',
                    delay: 10
                },
                hide: {
                    event: 'unfocus',
                    delay: 10,
                    fixed: true,
                    inactive: 15000
                },
                style: {
                    classes: 'qtip-aui-inline-dialog-clone'
                }
            });
        }
    }

    ScriptRunner["Administration"] = {
        "buildDeleteLinkRegistrationHandler": buildDeleteLinkRegistrationHandler
    };
})(AJS.$);
