(function ($, SR) {
    // normally would be only refreshing on a sucessful run
    var paramsShown = "/start/com.onresolve.scriptrunner.canned.jira.workflow.listeners.JiraRemoteEventHandlerDispatcher " +
        "/start/com.onresolve.scriptrunner.canned.bitbucket.events.BitbucketRemoteEventHandlerDispatcher " +
        "/start/com.onresolve.scriptrunner.canned.confluence.events.ConfluenceRemoteEventHandlerDispatcher ";

    $(document).off(paramsShown).on(paramsShown, function () {
        AJS.$("#projects").val("").closest("div.field-group").hide();
    });
})(AJS.$, ScriptRunner);