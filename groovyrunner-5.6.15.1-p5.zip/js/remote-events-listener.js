require("wr-dependency!com.atlassian.auiplugin:aui-select2");

import './icon-wait.css'

(function ($, SR) {
    // normally would be only refreshing on a sucessful run
    var paramsShown = "/start/" + "com.onresolve.scriptrunner.canned.jira.workflow.listeners.JiraRemoteCustomListener " +
        "/start/" + "com.onresolve.scriptrunner.canned.bitbucket.events.BitbucketRemoteCustomListener " +
        "/start/" + "com.onresolve.scriptrunner.canned.confluence.events.ConfluenceRemoteCustomListener";

    $(document).off(paramsShown).on(paramsShown, function () {

        console.log("params shown");

        var $fieldAppLinkId = $("#FIELD_APP_LINK_ID");

        // put any event here to allow submit, overwritten later
        if (!! _.find($("#events option"), function(i) {return i.text === "SpaceCreateEvent"})) {
            // confluence
            $("#events").val(["com.atlassian.confluence.event.events.space.SpaceCreateEvent"]);
        }
        else {
            // jira
            $("#events").val(["com.atlassian.crowd.event.group.AutoGroupCreatedEvent"]);
        }
        $("#events").closest("div.field-group").hide();

        // hide jira project picker
        $("#projects").val("").closest("div.field-group").hide();

        $fieldAppLinkId.off("change").on("change", function (e) {

            var appLinkId = $fieldAppLinkId.val();
            var $remoteEventsField = $("#FIELD_REMOTE_EVENTS");

            $remoteEventsField.attr("disabled", !appLinkId);

            if (!! appLinkId) {

                var $spinner = $('<span class="aui-icon aui-icon-wait">Wait</span>');
                $fieldAppLinkId.after($spinner);

                jQuery.ajax({
                    type      : "GET",
                    dataType  : "json",
                    url       : SR.Base.getBaseUrl() + "/rest/scriptrunner/latest/remote-events/available/" + appLinkId
                }).done(function (data) {
                    console.log(data);

                    var currentValue = $remoteEventsField.val();
                    var html = ScriptRunner.Templates.Params.multigroupedList({
                        name       : "FIELD_REMOTE_EVENTS",
                        label      : "Remote Events",
                        description: "Which events to fire on .",
                        type       : "multigroupedList",
                        values     : data,
                        value      : currentValue,
                        cssClasses : 'aui-select2'
                    });

                    $remoteEventsField.closest("div.field-group").replaceWith($(html));

                    $("#FIELD_REMOTE_EVENTS").auiSelect2();
                }).fail(function (data, textStatus, errorThrown) {
                    var errorObject = jQuery.parseJSON(data["responseText"]) || {
                        'message': errorThrown, 'status-code': data["status"]
                    };

                    SR.Base.handleErrors(errorObject)
                }).complete(function () {
                    $spinner.remove();
                })
            }
        });

        $fieldAppLinkId.trigger("change");
    });
})(AJS.$, ScriptRunner);
