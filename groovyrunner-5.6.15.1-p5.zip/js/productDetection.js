(function ($) {
    if (typeof ScriptRunner === "undefined") {
        window["ScriptRunner"] = {};
    }

    function isBitbucket() {
        return PLATFORM_NAME === 'bitbucket'
    }

    function isJira() {
        return PLATFORM_NAME === 'jira'
    }

    function isConfluence() {
        return PLATFORM_NAME === 'confluence'
    }

    function isBamboo() {
        return PLATFORM_NAME === 'bamboo'
    }

    ScriptRunner["Product"] = {
        isBitbucket: isBitbucket,
        isConfluence: isConfluence,
        isJira: isJira,
        isBamboo: isBamboo,
        productName: PLATFORM_NAME
    };
})(AJS.$);
