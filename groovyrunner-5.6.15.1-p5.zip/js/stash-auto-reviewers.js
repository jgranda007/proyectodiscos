require('./jquery.livequery');
require('wr-dependency!directIdeaIntegration');
require('wr-dependency!com.atlassian.auiplugin:aui-labels');
require('wr-dependency!com.atlassian.bitbucket.bitbucket-web:global');

const events = require('bitbucket/util/events');
const $ = AJS.$;

let mandatoryReviewersMap = {}, mandatoryReviewers = [], mandatoryReviewersIDs = [];

function mapUser(userList, isMandatory) {
    return _.map(userList, function (element) {
        return {
            id    : element.user.name,
            item  : element.user,
            text  : element.user.displayName,
            locked: isMandatory
        };
    });
}

function addRevPRCreate(userSelect, source, dest) {
    $.ajax(AJS.contextPath() + '/rest/scriptrunner-bitbucket/latest/auto-reviewers/byRef',
        {
            data   : {
                fromRepoId: source.repo,
                from      : source.branch,
                toRepoId  : dest.repo,
                to        : dest.branch
            },
            error  : function (xhr, status, errorMsg) {
                console.error(status + ' ' + errorMsg);
            },
            success: function (data) {
                let users = mapUser(data.mandatory, true).concat(mapUser(data.suggested, false));

                if (typeof users !== 'undefined' && users.length > 0) {
                    users = users.concat(userSelect.data());
                    userSelect.data(users);
                }
            }
        }
    );
}

function getPRDataFromPage() {
    const dataSection = $('section#content');
    let pullRequest = null;

    if (dataSection.length) {
        pullRequest = {
            projectKey   : dataSection.data('projectkey'),
            repoSlug     : dataSection.data('reposlug'),
            pullRequestId: dataSection.data('pullrequestid'),
            toBranchRef  : $('input#toRef-field').val()
        }
    }
    return pullRequest;
}

function addRevPREdit(userSelect) {

    $.ajax(AJS.contextPath() + '/rest/scriptrunner-bitbucket/latest/auto-reviewers/byPullRequestId',
        {
            data   : getPRDataFromPage(),
            error  : function (xhr, status, errorMsg) {
                console.error(status + ' ' + errorMsg);
            },
            success: function (data) {
                mandatoryReviewers = mapUser(data.mandatory, true);
                _.each(mandatoryReviewers, function (reviewer) {
                    mandatoryReviewersMap[reviewer.item.id] = reviewer;
                });

                setUserSelect(userSelect, data.mandatory);
            }
        }
    );
}

function setUserSelect(userSelect, mandatoryReviewers) {
    let currentReviewers = userSelect.data(), userSelectIDs = getUserIDs(currentReviewers),
        sharedElements = _.without(mandatoryReviewersIDs, userSelectIDs);
    mandatoryReviewersIDs = getUserIDs(mandatoryReviewers);

    const missing = _.difference(mandatoryReviewersIDs, userSelectIDs);

    if (missing) {
        currentReviewers = currentReviewers.concat(_.map(missing, function (missingReviewer) {
            return mandatoryReviewersMap[missingReviewer];
        }));
    }

    _.each(currentReviewers, function (reviewer) {
        if (_.contains(sharedElements, reviewer.item.id) || _.contains(_.intersection(userSelectIDs, mandatoryReviewersIDs), reviewer.item.id)) {
            reviewer.locked = "true";
        }
    });

    if (typeof currentReviewers !== 'undefined' && currentReviewers.length > 0) {
        userSelect.data(currentReviewers);
    }
}

function getUserIDs(reviewers) {
    return _.map(reviewers, function (reviewer) {
        if (reviewer.id === undefined) {
            return reviewer.user.id;
        } else {
            return reviewer.item.id;
        }
    });
}

function onEvent(event, func) {
    events.off(event, func);
    events.on(event, func);
}

const init = function () {
    _.defer(function () {
        onEvent('bitbucket.model.page-state.changed.targetBranch', addUsersToReviewers);

        $('div#edit-pull-request-dialog fieldset.pull-request-details').livequery(function () {
            addUsersToReviewers();
            onEvent('bitbucket.feature.repository.revisionReferenceSelector.revisionRefChanged', addUsersToReviewers);
            $.ajaxPrefilter(function (options, originalOptions) {
                // do not send data for POST/GET/DELETE
                if (originalOptions.type !== 'PUT' || options.type !== 'PUT') {
                    return;
                }


                const requestData = AJS.$.parseJSON(options.data);

                const existentReviewersIDs = _.map(requestData.reviewers, function (reviewer) {
                    return reviewer.user.id
                });

                const newReviewersIDs = _.difference(mandatoryReviewersIDs, existentReviewersIDs);

                if (newReviewersIDs) {
                    const missingReviewers = _.filter(mandatoryReviewers, function (reviewer) {
                        return _.contains(newReviewersIDs, reviewer.item.id);
                    }).map(function (user) {
                        return {user: user.item}
                    });

                    requestData.reviewers = requestData.reviewers.concat(missingReviewers);
                    options.data = JSON.stringify(requestData);
                }
            });
        });

        $('div.pull-request-create-form #s2id_reviewers:visible').livequery(function () {
            addUsersToReviewers();
        });

    });
};

const addUsersToReviewers = function () {

    const sourceRepo = $('input[name=fromRepoId]').val();
    const sourceBranch = $('input[name=fromBranch]').val();

    const destRepo = $('input[name=toRepoId]').val();
    const destBranch = $('input[name=toBranch]').val();

    // Available in Edit Mode
    const destBranchEditMode = $('input#toRef-field').val();
    const userSelect = $('.field-group.pull-request-reviewers #reviewers').data('select2');

    if (destBranchEditMode) {
        addRevPREdit(userSelect)
    } else {
        if (sourceRepo && sourceBranch && destRepo && destBranch) {
            addRevPRCreate(userSelect, {
                repo  : sourceRepo,
                branch: sourceBranch
            }, {
                repo  : destRepo,
                branch: destBranch
            });
        }
    }
};

AJS.$(document).ready(init);
