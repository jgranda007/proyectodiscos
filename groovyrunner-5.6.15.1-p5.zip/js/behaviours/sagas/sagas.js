import {call, put, takeEvery, takeLatest} from 'redux-saga/effects'
import {fetchEpic, fetchSprint, setSprintField} from "./sprint-field-utils";

export const SPRINT_FETCH_TYPE = "SPRINT_FETCH";
export const EPIC_FETCH_TYPE = "EPIC_FETCH";

export const ApiFetchUser = (userId) => {
    console.log("fetch user", userId);
    return fetch(`${AJS.contextPath()}/rest/api/2/user?username=${userId}`, {
        credentials: "same-origin",
    })
        .then (response => {
            if (! [200, 404].includes(response.status) ) {
                throw new Error("Problem getting user")
            }
            return response
        })
        .then(response => response.json())
        .then(json => {
            if ("errorMessages" in json) {
                throw new Error(`No such user: ${json.errorMessages.join(", ")}`)
            }
            return {displayName: json.displayName}
        })

};

// worker Saga: will be fired on USER_FETCH_REQUESTED actions
export function* fetchUser(action) {
    try {
        console.log("action", action);
        const data = yield call(ApiFetchUser, action.userId);
        yield put({type: "USER_FETCH_SUCCEEDED", data});

    } catch (e) {
        yield put({type: "USER_FETCH_FAILED", message: e.message});
    }
}

export function* fetchAndSetSprintField({sprintId, fieldId}) {
    try {
        const data = yield call(fetchSprint, sprintId);

        yield call(setSprintField, fieldId, data);

        yield put({type: `${SPRINT_FETCH_TYPE}_SUCCEEDED`, payload: data, item: {fieldId: fieldId}});

    } catch (e) {
        console.log(e);
        yield put({type: `${SPRINT_FETCH_TYPE}_FAILED`, message: e.message});
    }
}

export function* fetchAndSetEpicField({epicId, fieldId}) {
    try {
        const data = yield call(fetchEpic, epicId, fieldId);

        yield put({type: `${EPIC_FETCH_TYPE}_SUCCEEDED`, payload: data, item: {fieldId: fieldId}});

    } catch (e) {
        console.log(e);
        yield put({type: `${EPIC_FETCH_TYPE}_FAILED`, message: e.message});
    }
}

export default function* rootSagas() {
    yield takeEvery("USER_FETCH_REQUESTED", fetchUser);
    yield takeLatest(`${SPRINT_FETCH_TYPE}_REQUESTED`, fetchAndSetSprintField);
    yield takeLatest(`${EPIC_FETCH_TYPE}_REQUESTED`, fetchAndSetEpicField);
}

