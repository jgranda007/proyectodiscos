export const fetchSprint = async (sprintId) => {
    const response = await fetch(`${AJS.contextPath()}/rest/agile/1.0/sprint/${sprintId}`, {
        method     : 'GET',
        credentials: "same-origin",
        headers    : {
            "Content-Type": "application/json",
        }
    });

    if (response.status !== 200) {
        console.log("Erroring, can't set sprint, status", response.status);
        throw new Error("Sprint not found");
    }

    const json =  await response.json();
    if (! ("id" in json)) {
        throw new Error("Malformed response from picker");
    }

    return json
};

export const setSprintField = (fieldId, {id, name}) => {
    const sprintIdStr = id.toString();
    const $option = $("<option/>", {text: name, value: sprintIdStr, title: name});
    $option.data("descriptor", new AJS.ItemDescriptor({
        value: sprintIdStr,
        label: name,
    }));

    const $field = $(`#${fieldId}`);
    $field.append($option);
    $field.trigger("set-selection-value", sprintIdStr);
};

export const fetchEpic = async (epicId, fieldId) => {
    // find ID of epic name
    const fields = await fetch(`${AJS.contextPath()}/rest/api/2/field`, {
        method     : 'GET',
        credentials: "same-origin",
        headers    : {
            "Content-Type": "application/json",
        }
    }).then(response => response.json());

    let epicNameField = _.find(fields, function (item) {
        return item.schema && item.schema.custom && item.schema.custom === "com.pyxis.greenhopper.jira:gh-epic-label"
    });

    if (! epicNameField) {
        throw("Failed to find ID of Epic Link field");
    }

    const data = await fetch(`${AJS.contextPath()}/rest/api/2/issue/${epicId}?fields=${epicNameField.id}`, {
        method     : 'GET',
        credentials: "same-origin",
        headers    : {
            "Content-Type": "application/json",
        }
    }).then(response => response.json());

    const epicKey = "key:" + data.key;

    if (data.fields && data.fields[epicNameField.id]) {
        const $option = $("<option/>", {text: data.fields[epicNameField.id], value: epicKey});
        $option.data("descriptor", new AJS.ItemDescriptor({
            value: epicKey,
            label: data.fields[epicNameField.id]
        }));

        const $field = $(`#${fieldId}`);
        $field.append($option);
        $field.trigger("set-selection-value", epicKey);
    }
    else {
        throw new Error ("Failed to read epic name field from issue: " + epicId + " - perhaps it wasn't an epic");
    }
};