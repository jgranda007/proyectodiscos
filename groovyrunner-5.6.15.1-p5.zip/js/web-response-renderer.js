require('wr-dependency!jira.webresources:util')

require("./jquery.livequery");
require("./productDetection.js");

if (!AJS.dialog2 && JIRA && JIRA.Version.isGreaterThanOrEqualTo("8.6")) {
    require('wr-dependency!com.atlassian.auiplugin:dialog2');
}

(function ($) {
    $(function () {
        const webItemsKey = 'com.onresolve.' + ScriptRunner.Product.productName + '.groovy.groovyrunner:web-item-response-renderer.web-item-actions-data-provider';
        const webItems = WRM.data.claim(webItemsKey);

        const initialise = function (event, $context, reason) {

            if (reason === "panelRefreshed" || !reason) {

                //Do not try to bind event by id for service desk web items. Seems service desk append plugin key as part of the id.
                //I could not bind the event even if I append the id with plugin key. Need to check in future.
                if ((ScriptRunner.Product.productName === 'bamboo' || isJiraAndNonServiceDeskUrl()) && webItems !== undefined) {
                    $.each(webItems, function (i, item) {
                        var id = item["id"];
                        var action = item["action"];
                        register(action, id);
                    });
                }
                else {
                    //click event is bound through class selector instead of id for jira service desk, Confluence, Bitbucket etc.
                    registerLegacyActions();
                }

                // this needs to be added to a static resource, unless we automatically wire Close buttons to close the dialog
                AJS.dialog2.off('show').on("show", function (e) {
                    var targetId = e.target.id;
                    if (targetId === "sr-dialog") {
                        var srDialog = AJS.dialog2(e.target);
                        $(e.target).find("#dialog-close-button").click(function (e) {
                            e.preventDefault();
                            srDialog.hide();
                            srDialog.remove();
                        });
                    }
                });
            }
        };

        $(document).bind("newContentAdded", initialise);
        initialise(null, $(document), null);

        // hack for JA, which emits no events - https://jira.atlassian.com/browse/JSW-13527
        // When only supporting IE11+ switch to MutationObserver, or expire and re-add the livequery
        if (window.location.href.indexOf("RapidBoard.jspa?") > -1) {
            $("#ghx-detail-issue, #gh-ctx-menu-content").livequery((i, el) => {
                registerLegacyActions();
            });
        }

        function renderDialog(anchor) {
            const postActionFn = anchor.data("postActionFn");
            AJS.$.ajax({
                type    : "GET",
                dataType: "html",
                url     : anchor.attr("href")
            }).done(function (data) {
                AJS.dialog2($(data)).show();
            }).fail(function (jqXHR, textStatus, errorThrown) {
                console.warn("Failed to execute remote:", errorThrown);
            }).always(() => {
                if (typeof postActionFn === 'function') {
                    postActionFn()
                }
            });
        }

        function renderFlag(anchor) {
            const postActionFn = anchor.data("postActionFn");
            require(['aui/flag'], function (flag) {
                AJS.$.ajax({
                    type    : "GET",
                    dataType: "json",
                    url     : anchor.attr("href")
                }).done(function (data) {
                    flag(data);
                }).fail(function (jqXHR, textStatus, errorThrown) {
                    console.warn("Failed to execute remote:", errorThrown);
                }).always(() => {
                    if (typeof postActionFn === 'function') {
                        postActionFn()
                    }
                });
            });
        }

        function register(action, id) {
            if (action === "RUN_CODE_SHOW_DIALOG") {
                bindEventHandlerTo(id, renderDialog);
            }

            if (action === "RUN_CODE_SHOW_FLAG") {
                bindEventHandlerTo(id, renderFlag);
            }
        }

        function registerActionsForSrClasses() {
            // bind to class as well if there, binding to id does not work in all cases
            // also for service desk binding to a class does executes early before element loaded
            bindEventHandlerTo(".sr-trigger-dialog", renderDialog);
            bindEventHandlerTo(".sr-trigger-flag", renderFlag);
        }

        function registerLegacyActions() {
            registerActionsForSrClasses();

            $("aui-inline-dialog, aui-inline-dialog2").on("aui-show aui-layer-show", function () {
                registerActionsForSrClasses();
            });
        }

        function bindEventHandlerTo(selector, callback) {
            var element = $(document);
            element.off('click.sr-fragments', selector).on("click.sr-fragments", selector, clickHandler(callback));

            element.children().off('click.sr-fragments', selector).on("click.sr-fragments", selector, clickHandler(callback));
        }

        function clickHandler(callback) {
            return function (e) {
                e.preventDefault();
                // the following code allows us to find the element with the closest href w.r.t
                // as in some locations (for example dropdowns and repo actions in BBS)
                // the target element that is clicked can either be the <a href="link"> or <li> element
                const $targetElement = $(e.target);
                const ancestorAnchor = $targetElement.closest("[href]");
                const childAnchor = $targetElement.find("[href]").andSelf();

                callback(ancestorAnchor.length !== 0 ? ancestorAnchor : childAnchor);

                // this fires twice otherwise
                return false;
            }
        }

        function isJiraAndNonServiceDeskUrl() {
            return ScriptRunner.Product.productName === 'jira' && window.location.href.indexOf('/servicedesk/customer') < 0;
        }
    });
})(AJS.$);
